# QuoteBook v1 — 柜台报价助手

给 Unikar Auto Pieces 柜台用的报价工具。**不碰 Nexpart 的目录、不碰 capp 的价格体系**——只做"报价"这一件事：

- **报价**：选车 → 选品类 → 级联筛选（品牌 / coated / 位置）→ good·better·best 档位并排 → 按客户类型（散客 / 修车厂）取 capp 价格层 → 一键生成 EN/FR 报价文本（复制贴到 WhatsApp）
- **记录**：每次保存的报价自动写入报价日志（日期 / 客户 / 车型 / VIN / 明细 / 成交与否 / 未成交原因）
- **分析**：成交率（总体 + 按档位）、每日报价数、热门品类、未成交原因
- **配件管理**：配件增删改（对着 capp 填散客价 / 修车厂价 / 成本 / 库存备注）、车辆新增
- **粘贴导入**：供应商查询原文（CBK / Transbec / Transit / Bestbuy）往文本框一贴，自动解析，核对后一键入库；品类不在列表里可当场新建。v1.2 升级：多件批量解析（一次粘贴多件，逐件勾选入库）、Bestbuy 管道格式（`品牌 | 件号 | 品类`）、自动抓取 Alternate Parts / Superceded Parts 段落（件号+现货+价格进适用说明）、Sell→成本、On Hand→库存备注、首行车型识别提示
- **互换件 alternate**：报价页每行有"互换"按钮，展开显示两组备选——同 OEM 号（跨品牌/供应商互换，在配件管理里填 OEM 号即自动关联）、同车型同品类（档位备选）；Bestbuy 这类没有数据 feed 的供应商，靠 OEM 号搭桥混进备选

数据种子：`seed_parts.csv`（来自 cross-reference workbook，172 条，4 款车）。capp 的价格层目前是空的——在"配件管理"里按 capp 的 Net/List/Dealer/Jobber 对应填进去。

## 在 VPS 上部署（Ubuntu 24.04，手动复制粘贴执行）

假设 tarball 已传到 VPS 的 `/root/`（或任何目录）：

```bash
# 1. 解压到 /opt/quotebook
sudo mkdir -p /opt/quotebook
sudo tar -xzf quotebook-v1.tar.gz -C /opt/quotebook --strip-components=1
cd /opt/quotebook

# 2. 建专用用户并授权
sudo useradd -r -s /usr/sbin/nologin quotebook 2>/dev/null || true
sudo chown -R quotebook:quotebook /opt/quotebook

# 3. 虚拟环境 + 依赖
sudo -u quotebook python3 -m venv /opt/quotebook/venv
sudo -u quotebook /opt/quotebook/venv/bin/pip install -r /opt/quotebook/requirements.txt

# 4. 导入种子数据（只跑一次）
sudo -u quotebook /opt/quotebook/venv/bin/python /opt/quotebook/import_seed.py \
  --csv /opt/quotebook/seed_parts.csv \
  --db /opt/quotebook/data/quotebook.db

# 5. systemd 服务
sudo cp /opt/quotebook/quotebook.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now quotebook
sudo systemctl status quotebook   # 应为 active (running)

# 6. nginx：把 snippet 内容加进 odosnap.com 的 server { } 块里
sudo cp /opt/quotebook/nginx-quotebook-snippet.conf /etc/nginx/snippets/quotebook.conf
# 然后手动编辑 odosnap.com 的站点配置，在 server 块内加一行：
#     include snippets/quotebook.conf;
sudo nginx -t && sudo systemctl reload nginx

# 7. 验证
curl -s http://127.0.0.1:8091/api/version   # 应返回 {"version":"v1"}
# 浏览器打开 https://odosnap.com/quotebook/
```

升级/重建：覆盖 `/opt/quotebook` 下的代码文件后 `sudo systemctl restart quotebook` 即可；数据库在 `data/quotebook.db`，**不要删除**（删了报价记录就没了）。

## 本地试运行

```bash
python3 -m venv venv && ./venv/bin/pip install -r requirements.txt
python3 import_seed.py --csv seed_parts.csv --db data/quotebook.db
python3 app.py   # http://127.0.0.1:8091
```

## 非目标（v1 明确不做）

- 不接 Nexpart、不接 capp：数据靠种子导入 + 手工维护
- 无登录鉴权：默认只跑在内网/127.0.0.1，后面经 nginx 对外时请自行加访问控制
- 无 VIN 解码：VIN 只做记录字段
- 价格全部手工维护（对着 capp 填），工具不算价、不调价

## 文件清单

| 文件 | 说明 |
|---|---|
| `app.py` | Flask 主程序（页面 + API） |
| `schema.sql` | SQLite 表结构 |
| `import_seed.py` | 种子导入（workbook xlsx → CSV → DB） |
| `seed_parts.csv` | 172 条种子配件数据 |
| `requirements.txt` | `flask>=3.0` |
| `templates/` | 4 个页面模板（报价/记录/分析/配件管理） |
| `quotebook.service` | systemd 单元 |
| `nginx-quotebook-snippet.conf` | nginx location 片段（挂 `/quotebook/`） |
