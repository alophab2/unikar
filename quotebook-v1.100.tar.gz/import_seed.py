#!/usr/bin/env python3
"""QuoteBook v1 seed importer.

Two modes:
  1. Build a portable CSV from the cross-reference workbook (needs openpyxl, run once):
       python3 import_seed.py --xlsx /path/to/cross-reference-2019-civic-control-arm.xlsx --out seed_parts.csv
  2. Load the CSV into the SQLite DB (stdlib only, safe to run on the VPS):
       python3 import_seed.py --csv seed_parts.csv --db /opt/quotebook/data/quotebook.db

The CSV is the shippable seed; the xlsx never needs to leave the office.
"""
import argparse
import csv
import re
import sqlite3
import sys

# sheet -> vehicle label
VEHICLES = {
    "Driver Side (Left)":   ("2019 Honda Civic 2.0L", "2019", "Honda", "Civic", "2.0L"),
    "Passenger Side (Right)": ("2019 Honda Civic 2.0L", "2019", "Honda", "Civic", "2.0L"),
    "2010 Civic 1.8L":       ("2010 Honda Civic 1.8L", "2010", "Honda", "Civic", "1.8L"),
    "2021 Silverado 1500":  ("2021 Chevrolet Silverado 1500", "2021", "Chevrolet", "Silverado 1500", ""),
    "2023 BMW X5 xDrive45e": ("2023 BMW X5 xDrive45e", "2023", "BMW", "X5", "xDrive45e"),
}

# English part name -> Chinese category (ORDER MATTERS: more specific first)
CATEGORIES = [
    ("wear sensor", "刹车片感应线"),
    ("rotor", "刹车盘"),
    ("pad", "刹车片"),
    ("ball joint", "下球头"),
    ("tie rod", "外拉杆球头"),
    ("control arm", "下摆臂"),
    ("compressor", "空调压缩机"),
]

# Curated seed fixes for the flagship good/better/best demo trio (Silverado front rotors).
# The workbook notes don't spell out coated/uncoated for every row; make it explicit here.
SEED_COATED_OVERRIDES = {
    "55407": "uncoated",       # ULTRA plain
    "YH653387P": "coated",     # Carquest Platinum painted
    "YH653387HC": "coated",    # Carquest High Carbon coated
}

POSITION_MAP = {
    "Front Left Lower": "L", "Front Left": "L", "Left": "L",
    "Front Right Lower": "R", "Front Right": "R", "Right": "R",
}


def map_category(part_name, sheet):
    if part_name:
        low = part_name.lower()
        # strip parenthetical variant tags like " (Brembo J49)" before matching
        low = re.sub(r"\s*\(.*?\)", "", low)
        for key, cn in CATEGORIES:
            if key in low:
                return cn, re.sub(r"\s*\(.*?\)", "", part_name).strip()
    if sheet.startswith("Driver Side") or sheet.startswith("Passenger Side"):
        return "下摆臂", "Front Lower Control Arm"
    return "其他", (part_name or "").strip()


def detect_coated(notes):
    if not notes:
        return ""
    n = notes.lower()
    if re.search(r"non-?painted|non-?coated|unpainted|uncoated|\bplain\b", n):
        return "uncoated"
    if "coated" in n or "painted" in n:
        return "coated"
    return ""


def extract_specs(notes):
    """Pull a short spec (e.g. '343mm', '374mm x 36mm') out of fitment notes."""
    if not notes:
        return ""
    m = re.search(r"\d{3,4}\s*mm(\s*x\s*\d+\s*mm)?", notes, re.I)
    if m:
        extra = " vented" if "vented" in notes.lower() else ""
        return m.group(0).strip() + extra
    m = re.search(r"\d+\.\d+\s*in", notes, re.I)
    return m.group(0).strip() if m else ""


def build_csv(xlsx_path, out_path):
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    rows = []
    for sheet, (vlabel, year, make, model, trim) in VEHICLES.items():
        ws = wb[sheet]
        headers = [c.value for c in ws[1]]
        col = {h: headers.index(h) for h in headers if h}

        def val(r, h):
            return ws.cell(r, col[h] + 1).value if h in col else None

        for r in range(2, ws.max_row + 1):
            brand = val(r, "Brand")
            part_number = val(r, "Part Number")
            if not brand or not part_number:
                continue
            part_name = val(r, "Part") if "Part" in col else None
            category, clean_part = map_category(part_name, sheet)
            notes = val(r, "Fitment Notes") or ""
            bj = val(r, "Ball Joint Included")
            if bj:
                notes = (notes + " | Ball joint: %s" % bj).strip(" |")
            nex_price = val(r, "Nexpart Your Price (CAD)")
            ra_price = val(r, "RockAuto Price (CAD)")
            cost = nex_price if nex_price is not None else ra_price
            pos_raw = val(r, "Position")
            position = POSITION_MAP.get((pos_raw or "").strip(), "")
            # directional L/R hints inside notes for BMW rotors
            if not position:
                if re.search(r"\bLEFT\b", notes): position = "L"
                elif re.search(r"\bRIGHT\b", notes): position = "R"
            rows.append({
                "vehicle_label": vlabel, "year": year, "make": make,
                "model": model, "trim": trim,
                "category": category,
                "brand": str(brand).strip(),
                "part_number": str(part_number).strip(),
                "specs": extract_specs(notes),
                "coated": SEED_COATED_OVERRIDES.get(str(part_number).strip(),
                                                    detect_coated(notes)),
                "position": position,
                "fitment_notes": notes.strip(),
                "tier": "",  # assigned below by price rank
                "cost": cost if cost is not None else "",
                "stock_note": (val(r, "Nexpart Stock") or "") if "Nexpart Stock" in col else "",
                "seller": (val(r, "Nexpart Seller") or "") if "Nexpart Seller" in col else "",
            })

    # tier by price rank within (vehicle, category, position, size) groups.
    # Only small groups (2-6) get tiers: they are genuine alternates for one job.
    # Big groups (e.g. 19 control-arm variants across trims) are left NULL for
    # the user to curate in 配件管理 — price-ranking them would be misleading.
    def size_key(specs):
        m = re.search(r"(\d{3,4})\s*mm", specs or "", re.I)
        return m.group(1) if m else ""
    from collections import defaultdict
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        try:
            c = float(row["cost"]) if row["cost"] != "" else None
        except (TypeError, ValueError):
            c = None
        groups[(row["vehicle_label"], row["category"], row["position"],
                size_key(row["specs"]))].append((c, i))
    for members in groups.values():
        priced = sorted([m for m in members if m[0] is not None])
        if not (2 <= len(priced) <= 6):
            continue
        for rank, (_, i) in enumerate(priced):
            rows[i]["tier"] = ["good", "better", "best"][min(rank, 2)]

    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print("wrote %d part rows -> %s" % (len(rows), out_path))


def load_csv(csv_path, db_path):
    import os
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")
    con = sqlite3.connect(db_path)
    con.executescript(open(schema_path, encoding="utf-8").read())
    with open(csv_path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    veh_ids, cat_ids = {}, {}
    n_parts = 0
    for row in rows:
        vl = row["vehicle_label"]
        if vl not in veh_ids:
            con.execute(
                "INSERT OR IGNORE INTO vehicles(label,year,make,model,trim) VALUES(?,?,?,?,?)",
                (vl, row["year"], row["make"], row["model"], row["trim"]))
            veh_ids[vl] = con.execute(
                "SELECT id FROM vehicles WHERE label=?", (vl,)).fetchone()[0]
        cn = row["category"]
        if cn not in cat_ids:
            con.execute("INSERT OR IGNORE INTO categories(name) VALUES(?)", (cn,))
            cat_ids[cn] = con.execute(
                "SELECT id FROM categories WHERE name=?", (cn,)).fetchone()[0]
        con.execute(
            """INSERT INTO parts(vehicle_id,category_id,brand,part_number,specs,coated,
                                 position,fitment_notes,tier,cost,stock_note,seller)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (veh_ids[vl], cat_ids[cn], row["brand"], row["part_number"],
             row["specs"] or None, row["coated"] or None, row["position"] or None,
             row["fitment_notes"] or None, row["tier"] or None,
             float(row["cost"]) if row["cost"] not in ("", None) else None,
             row["stock_note"] or None, row["seller"] or None))
        n_parts += 1
    con.commit()
    nv = con.execute("SELECT COUNT(*) FROM vehicles").fetchone()[0]
    con.close()
    print("loaded %d parts across %d vehicles -> %s" % (n_parts, nv, db_path))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx")
    ap.add_argument("--csv")
    ap.add_argument("--out")
    ap.add_argument("--db")
    a = ap.parse_args()
    if a.xlsx and a.out:
        build_csv(a.xlsx, a.out)
    elif a.csv and a.db:
        load_csv(a.csv, a.db)
    else:
        ap.print_help()
        sys.exit(2)


if __name__ == "__main__":
    main()
