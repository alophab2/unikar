#!/usr/bin/env python3
"""QuoteBook v1 — counter quoting workbench for the auto parts store.

Reads: part reference data (seeded from the cross-reference workbook; prices per
capp's price levels entered manually in 配件管理 or bulk-imported from a capp CSV export).
Does NOT: talk to Nexpart/capp APIs, decode VINs, or invent prices.

Run:  python3 app.py   (listens on 127.0.0.1:8091)
DB:   $QUOTEBOOK_DB or ./data/quotebook.db
"""
import os
import sqlite3
import csv
import io
import json
import secrets
import shutil
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, g, jsonify, redirect, render_template, request, session, \
    send_file, after_this_request
from werkzeug.security import check_password_hash, generate_password_hash

VERSION = "1.100"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("QUOTEBOOK_DB", os.path.join(APP_DIR, "data", "quotebook.db"))

STORE = {
    "name": "Unikar Auto Pieces",
    "phone": "+1 (514) 542-6088",
    "addr": "120-70 Boul Brunswick, Dollard-des-Ormeaux, QC",
}

CAT_EN = {"刹车盘": "Brake Rotor", "刹车片": "Brake Pads", "下摆臂": "Control Arm", "下球头": "Ball Joint", "外拉杆球头": "Tie Rod End", "内拉杆": "Inner Tie Rod", "轮毂轴承": "Wheel Bearing", "减震器": "Shock Absorber", "火花塞": "Spark Plug", "机油滤芯": "Oil Filter", "空气滤芯": "Air Filter", "滤芯": "Filter", "空调压缩机": "A/C Compressor", "刹车片感应线": "Brake Pad Wear Sensor", "刹车踏板垫": "Brake Pedal Pad", "发电机": "Alternator", "起动机": "Starter", "传感器": "Sensor", "刹车卡钳": "Brake Caliper", "刹车鼓": "Brake Drum", "刹车蹄片": "Brake Shoes", "刹车油管": "Brake Hose", "刹车附件包": "Brake Hardware Kit", "平衡杆球头": "Stabilizer Link", "平衡杆衬套": "Stabilizer Bushing", "下摆臂衬套": "Control Arm Bushing", "弹簧": "Coil Spring", "排气歧管": "Exhaust Manifold", "进气歧管": "Intake Manifold", "三元催化器": "Catalytic Converter", "消音器": "Muffler", "共振器": "Resonator", "排气管": "Exhaust Pipe", "排气垫片": "Exhaust Gasket", "排气螺丝": "Exhaust Bolt", "排气吊耳": "Exhaust Hanger", "空调滤芯": "Cabin Filter", "燃油滤芯": "Fuel Filter", "点火线圈": "Ignition Coil", "正时皮带": "Timing Belt", "皮带": "Belt", "水泵": "Water Pump", "节温器": "Thermostat", "鼓风机电机": "Blower Motor", "冷凝器": "Condenser", "电瓶": "Battery", "ABS传感器": "ABS Sensor", "半轴": "CV Axle", "其他": "Other"}
CAT_FR = {"刹车盘": "Disque de frein", "刹车片": "Plaquettes de frein", "下摆臂": "Bras de suspension", "下球头": "Rotule", "外拉杆球头": "Embout de biellette", "内拉杆": "Biellette intérieure", "轮毂轴承": "Roulement de roue", "减震器": "Amortisseur", "火花塞": "Bougie d'allumage", "机油滤芯": "Filtre à huile", "空气滤芯": "Filtre à air", "滤芯": "Filtre", "空调压缩机": "Compresseur de climatisation", "刹车片感应线": "Témoin d'usure", "刹车踏板垫": "Patin de pédale de frein", "发电机": "Alternateur", "起动机": "Démarreur", "传感器": "Capteur", "刹车卡钳": "Étrier de frein", "刹车鼓": "Tambour de frein", "刹车蹄片": "Mâchoires de frein", "刹车油管": "Flexible de frein", "刹车附件包": "Kit de frein", "平衡杆球头": "Biellette stabilisatrice", "平衡杆衬套": "Bague stabilisatrice", "下摆臂衬套": "Bague de bras de suspension", "弹簧": "Ressort", "排气歧管": "Collecteur d'échappement", "进气歧管": "Collecteur d'admission", "三元催化器": "Catalyseur", "消音器": "Silencieux", "共振器": "Résonateur", "排气管": "Tuyau d'échappement", "排气垫片": "Joint d'échappement", "排气螺丝": "Boulon d'échappement", "排气吊耳": "Support d'échappement", "空调滤芯": "Filtre habitacle", "燃油滤芯": "Filtre à carburant", "点火线圈": "Bobine d'allumage", "正时皮带": "Courroie de distribution", "皮带": "Courroie", "水泵": "Pompe à eau", "节温器": "Thermostat", "鼓风机电机": "Moteur de ventilation", "冷凝器": "Condenseur", "电瓶": "Batterie", "ABS传感器": "Capteur ABS", "半轴": "Cardan", "其他": "Autre"}
TIER_EN = {"economy": "Economy", "standard": "Standard", "premium": "Premium"}
TIER_FR = {"economy": "Économique", "standard": "Standard", "premium": "Premium"}

app = Flask(__name__)


def _load_secret():
    env = os.environ.get("QUOTEBOOK_SECRET")
    if env:
        return env
    p = os.path.join(os.path.dirname(DB_PATH), ".secret_key")
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    import secrets
    s = secrets.token_hex(32)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8").write(s)
    return s


app.secret_key = _load_secret()
app.permanent_session_lifetime = timedelta(days=30)


@app.context_processor
def inject_version():
    return {"ver": VERSION}


def current_staff():
    sid = session.get("staff_id")
    if not sid:
        return None
    r = get_db().execute("SELECT id, name, is_owner, active FROM staff WHERE id=?", (sid,)).fetchone()
    if not r or not r["active"]:
        session.pop("staff_id", None)
        return None
    return row2dict(r)


def owner_required_api(f):
    @wraps(f)
    def w(*a, **k):
        s = current_staff()
        if not s or not s["is_owner"]:
            return jsonify({"error": "owner only"}), 403
        return f(*a, **k)
    return w


def audit(action, target_type=None, target_id=None, details=None):
    """记录关键操作到审计日志（失败不影响主流程）。"""
    try:
        s = current_staff()
        get_db().execute(
            "INSERT INTO audit_log(staff_id, staff_name, action, target_type, target_id, details)"
            " VALUES(?,?,?,?,?,?)",
            (s["id"] if s else None, s["name"] if s else None,
             action, target_type, target_id, details))
        get_db().commit()
    except Exception:
        pass


def sync_supplier_price(db, part_id, supplier, cost, stock_note=None):
    """供应商价格同步：upsert 该供应商的报价，并把 parts.cost/seller 设为最优价。
    同一配件号不同供应商各存一条，报价用最低价。"""
    if not supplier or cost is None:
        return
    try:
        cost = float(cost)
    except (ValueError, TypeError):
        return
    db.execute(
        """INSERT INTO supplier_prices(part_id, supplier, cost, stock_note, updated_at)
           VALUES(?,?,?,?,datetime('now','localtime'))
           ON CONFLICT(part_id, supplier) DO UPDATE SET
             cost=excluded.cost, stock_note=excluded.stock_note,
             updated_at=datetime('now','localtime')""",
        (part_id, supplier, cost, stock_note))
    # 最优价回写到 parts
    best = db.execute(
        "SELECT supplier, cost FROM supplier_prices"
        " WHERE part_id=? AND cost IS NOT NULL ORDER BY cost ASC LIMIT 1",
        (part_id,)).fetchone()
    if best:
        db.execute("UPDATE parts SET cost=?, seller=? WHERE id=?",
                   (best[1], best[0], part_id))



@app.before_request
def _auth_gate():
    # public: login page + version probe; everything else needs a session.
    # request.path may or may not include the /quotebook prefix (nginx),
    # so match by suffix.
    p = request.path
    if p.rsplit("/", 1)[-1] in ("login", "needs_setup") or p.endswith("/api/version") \
            or p.startswith("/static/"):
        return None
    if not session.get("staff_id"):
        if "/api/" in p:
            return jsonify({"error": "login required"}), 401
        return redirect("login")
    # 每日自动备份：每天第一次有效请求时触发
    _maybe_auto_backup()
    return None


# ---------- 每日自动备份 ----------
BACKUP_DIR = os.path.join(os.path.dirname(DB_PATH), "backups")
AUTO_BACKUP_KEEP = 7

def _maybe_auto_backup():
    """每天第一次请求时自动备份数据库，保留最近 7 份。"""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        today = datetime.now().strftime("%Y%m%d")
        # 今天已备份就跳过（检查文件名日期前缀）
        for f in os.listdir(BACKUP_DIR):
            if f.startswith(f"quotebook-auto-{today}"):
                return
        # VACUUM INTO 做一致性快照
        tmp = os.path.join(BACKUP_DIR, f"quotebook-auto-{today}.db")
        get_db().execute("VACUUM INTO ?", (tmp,))
        # 只保留最近 7 份
        autos = sorted(f for f in os.listdir(BACKUP_DIR)
                       if f.startswith("quotebook-auto-"))
        for old in autos[:-AUTO_BACKUP_KEEP]:
            try:
                os.unlink(os.path.join(BACKUP_DIR, old))
            except OSError:
                pass
    except Exception:
        pass  # 备份失败不影响正常请求


@app.get("/api/audit")
@owner_required_api
def api_audit_list():
    """审计日志（店主查看），最近 200 条。"""
    db = get_db()
    rows = [row2dict(r) for r in db.execute(
        """SELECT id, staff_name, action, target_type, target_id, details, created_at
           FROM audit_log ORDER BY id DESC LIMIT 200""")]
    return jsonify({"logs": rows})


@app.get("/api/backup/auto_list")
@owner_required_api
def api_backup_auto_list():
    """列出自动备份文件（店主查看）。"""
    try:
        files = sorted(
            (f for f in os.listdir(BACKUP_DIR) if f.startswith("quotebook-auto-")),
            reverse=True)
        out = []
        for f in files:
            fp = os.path.join(BACKUP_DIR, f)
            st = os.stat(fp)
            out.append({"name": f,
                        "size": st.st_size,
                        "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")})
        return jsonify({"backups": out, "keep": AUTO_BACKUP_KEEP})
    except FileNotFoundError:
        return jsonify({"backups": [], "keep": AUTO_BACKUP_KEEP})


@app.after_request
def _no_cache_html(resp):
    # HTML pages must never be cached: after each deploy the browser
    # must fetch the new templates instead of showing a stale copy
    if resp.content_type.startswith("text/html"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


# ---------- db ----------
def get_db():
    if "db" not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    with open(os.path.join(APP_DIR, "schema.sql"), encoding="utf-8") as f:
        con.executescript(f.read())
    # lightweight migrations for existing DBs
    for col in ("drivetrain", "fuel"):
        try:
            con.execute(f"ALTER TABLE vehicles ADD COLUMN {col} TEXT")
        except sqlite3.OperationalError:
            pass
    try:
        con.execute("ALTER TABLE parts ADD COLUMN stock_updated_at TEXT")
    except sqlite3.OperationalError:
        pass
    # 回填：从 label 开头的 4 位年份提取 year（如 "2021 Chevrolet ..."）
    con.execute("""UPDATE vehicles SET year = substr(label,1,4)
                   WHERE (year IS NULL OR year='')
                   AND substr(label,1,4) GLOB '[12][0-9][0-9][0-9]'""")
    con.execute("""CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, phone TEXT,
        ctype TEXT NOT NULL DEFAULT 'retail',
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')))""")
    try:
        con.execute("ALTER TABLE quotes ADD COLUMN customer_id INTEGER REFERENCES customers(id)")
    except sqlite3.OperationalError:
        pass
    try:
        con.execute("ALTER TABLE quotes ADD COLUMN staff_id INTEGER REFERENCES staff(id)")
    except sqlite3.OperationalError:
        pass
    # position vocabulary: L/R -> Left/Right (granular Front/Rear/... added later)
    try:
        con.execute("UPDATE parts SET position='Left' WHERE position='L'")
        con.execute("UPDATE parts SET position='Right' WHERE position='R'")
    except sqlite3.OperationalError:
        pass
    # tier vocabulary: good/better/best -> economy/standard/premium
    try:
        con.execute("UPDATE parts SET tier='economy' WHERE tier='good'")
        con.execute("UPDATE parts SET tier='standard' WHERE tier='better'")
        con.execute("UPDATE parts SET tier='premium' WHERE tier='best'")
        con.execute("UPDATE quote_items SET tier='economy' WHERE tier='good'")
        con.execute("UPDATE quote_items SET tier='standard' WHERE tier='better'")
        con.execute("UPDATE quote_items SET tier='premium' WHERE tier='best'")
    except sqlite3.OperationalError:
        pass
    con.commit()
    con.close()


def row2dict(r):
    return dict(r) if r is not None else None


# ---------- pages ----------
@app.get("/")
def page_quote():
    return render_template("quote.html", page="quote")


@app.get("/journal")
def page_journal():
    return render_template("journal.html", page="journal")


@app.get("/analytics")
def page_analytics():
    return render_template("analytics.html", page="analytics")


@app.get("/parts")
def page_parts():
    return render_template("parts.html", page="parts")


@app.get("/staff")
def page_staff():
    s = current_staff()
    if not s or not s["is_owner"]:
        return redirect("./")
    return render_template("staff.html", page="staff")


@app.get("/login")
def page_login():
    if session.get("staff_id") and current_staff():
        return redirect("./")
    return render_template("login.html")


# ---------- auth ----------
@app.get("/api/needs_setup")
def api_needs_setup():
    db = get_db()
    has = db.execute("SELECT id FROM staff LIMIT 1").fetchone()
    return jsonify({"setup": not bool(has)})


@app.post("/api/login")
def api_login():
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    pin = d.get("pin") or ""
    db = get_db()
    # first-time setup: no staff yet -> create owner
    if not db.execute("SELECT id FROM staff LIMIT 1").fetchone():
        if not name or len(pin) < 4:
            return jsonify({"error": "name and 4+ digit PIN required"}), 400
        cur = db.execute("INSERT INTO staff(name,pin_hash,is_owner) VALUES(?,?,1)",
                         (name, generate_password_hash(pin)))
        db.commit()
        session.permanent = True
        session["staff_id"] = cur.lastrowid
        return jsonify({"ok": True, "setup": True})
    r = db.execute("SELECT * FROM staff WHERE name=? AND active=1", (name,)).fetchone()
    if not r or not check_password_hash(r["pin_hash"], pin):
        return jsonify({"error": "bad credentials"}), 401
    session.permanent = True
    session["staff_id"] = r["id"]
    return jsonify({"ok": True})


@app.post("/api/logout")
def api_logout():
    session.pop("staff_id", None)
    return jsonify({"ok": True})


@app.get("/api/me")
def api_me():
    s = current_staff()
    if not s:
        return jsonify({"error": "login required"}), 401
    return jsonify(s)


@app.get("/api/staff")
@owner_required_api
def api_staff_list():
    db = get_db()
    rows = db.execute("SELECT id, name, is_owner, active, created_at FROM staff ORDER BY id").fetchall()
    return jsonify([row2dict(r) for r in rows])


@app.post("/api/staff")
@owner_required_api
def api_staff_add():
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    pin = d.get("pin") or ""
    if not name or len(pin) < 4:
        return jsonify({"error": "name and 4+ digit PIN required"}), 400
    db = get_db()
    try:
        cur = db.execute("INSERT INTO staff(name,pin_hash,is_owner) VALUES(?,?,?)",
                         (name, generate_password_hash(pin),
                          1 if d.get("is_owner") else 0))
    except sqlite3.IntegrityError:
        return jsonify({"error": "name taken"}), 400
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.patch("/api/staff/<int:sid>")
@owner_required_api
def api_staff_update(sid):
    d = request.get_json(force=True) or {}
    db = get_db()
    me = current_staff()
    sets, vals = [], []
    if "active" in d:
        if sid == me["id"] and not d["active"]:
            return jsonify({"error": "cannot disable self"}), 400
        sets.append("active = ?")
        vals.append(1 if d["active"] else 0)
    if d.get("pin"):
        if len(d["pin"]) < 4:
            return jsonify({"error": "PIN min 4 digits"}), 400
        sets.append("pin_hash = ?")
        vals.append(generate_password_hash(d["pin"]))
    if "name" in d and d["name"] and d["name"].strip():
        sets.append("name = ?")
        vals.append(d["name"].strip())
    if "is_owner" in d:
        if sid == me["id"] and not d["is_owner"]:
            return jsonify({"error": "cannot demote self"}), 400
        # 创始人谁也降级不了
        founder = db.execute("SELECT MIN(id) AS id FROM staff").fetchone()["id"]
        if sid == founder and not d["is_owner"]:
            return jsonify({"error": "cannot demote the original owner"}), 403
        sets.append("is_owner = ?")
        vals.append(1 if d["is_owner"] else 0)
    if not sets:
        return jsonify({"error": "nothing to update"}), 400
    db.execute(f"UPDATE staff SET {', '.join(sets)} WHERE id=?", vals + [sid])
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/staff/<int:sid>")
@owner_required_api
def api_staff_delete(sid):
    me = current_staff()
    if sid == me["id"]:
        return jsonify({"error": "cannot delete self"}), 400
    db = get_db()
    # 创始人（最早创建的账号）谁也删不掉
    founder = db.execute("SELECT MIN(id) AS id FROM staff").fetchone()["id"]
    if sid == founder:
        return jsonify({"error": "cannot delete the original owner"}), 403
    # 名下报价保留，staff_id 置空（分析页显示为未知）
    tgt = db.execute("SELECT name FROM staff WHERE id=?", (sid,)).fetchone()
    db.execute("UPDATE quotes SET staff_id=NULL WHERE staff_id=?", (sid,))
    cur = db.execute("DELETE FROM staff WHERE id=?", (sid,))
    db.commit()
    if not cur.rowcount:
        return jsonify({"error": "not found"}), 404
    if tgt:
        audit("delete_staff", "staff", sid, tgt["name"])
    return jsonify({"ok": True})


# ---------- meta ----------
@app.get("/api/version")
def api_version():
    return jsonify({"version": VERSION})


# ---------- vehicles ----------
@app.get("/api/vehicles")
def api_vehicles():
    db = get_db()
    return jsonify([row2dict(r) for r in
                    db.execute("SELECT * FROM vehicles ORDER BY label")])


@app.post("/api/vehicles")
def api_vehicle_add():
    d = request.get_json(force=True)
    if not d.get("label"):
        return jsonify({"error": "label required"}), 400
    db = get_db()
    cur = db.execute(
        "INSERT INTO vehicles(label,year,make,model,trim,drivetrain,fuel,notes) VALUES(?,?,?,?,?,?,?,?)",
        (d["label"], d.get("year"), d.get("make"), d.get("model"),
         d.get("trim"), d.get("drivetrain"), d.get("fuel"), d.get("notes")))
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.patch("/api/vehicles/<int:vid>")
def api_vehicle_update(vid):
    d = request.get_json(force=True) or {}
    db = get_db()
    r = db.execute("SELECT * FROM vehicles WHERE id=?", (vid,)).fetchone()
    if not r:
        return jsonify({"error": "not found"}), 404
    label = (d.get("label") or "").strip() or r["label"]
    db.execute("UPDATE vehicles SET label=?, year=?, drivetrain=?, fuel=? WHERE id=?",
               (label, d.get("year") or None, d.get("drivetrain") or None,
                d.get("fuel") or None, vid))
    db.commit()
    return jsonify({"ok": True, "id": vid, "label": label})


@app.delete("/api/vehicles/<int:vid>")
@owner_required_api
def api_vehicle_delete(vid):
    db = get_db()
    v = db.execute("SELECT label FROM vehicles WHERE id=?", (vid,)).fetchone()
    if not v:
        return jsonify({"error": "not found"}), 404
    # 有配件时阻止删除，防止误删数据
    n_parts = db.execute("SELECT COUNT(*) FROM parts WHERE vehicle_id=?", (vid,)).fetchone()[0]
    if n_parts:
        return jsonify({"error": "has_parts", "count": n_parts}), 400
    # 报价单保留快照，只断开关联
    db.execute("UPDATE quotes SET vehicle_id=NULL WHERE vehicle_id=?", (vid,))
    db.execute("DELETE FROM vehicles WHERE id=?", (vid,))
    db.commit()
    audit("delete_vehicle", "vehicle", vid, v["label"])
    return jsonify({"ok": True})


# ---------- categories ----------
@app.get("/api/categories")
def api_categories():
    db = get_db()
    vid = request.args.get("vehicle_id")
    if vid:
        rows = db.execute(
            """SELECT DISTINCT c.id, c.name FROM categories c
               JOIN parts p ON p.category_id = c.id
               WHERE p.vehicle_id = ? ORDER BY c.name""", (vid,))
    else:
        rows = db.execute("SELECT id, name FROM categories ORDER BY name")
    return jsonify([row2dict(r) for r in rows])


# ---------- parts ----------
PART_COLS = ("p.id,p.vehicle_id,p.category_id,p.brand,p.part_number,p.specs,p.coated,p.position,"
             "p.fitment_notes,p.tier,p.cost,p.stock_note,p.stock_updated_at,p.seller,p.price_retail,p.price_garage,"
             "p.oem_number")


def part_query(where, args):
    db = get_db()
    return [row2dict(r) for r in db.execute(
        f"""SELECT {PART_COLS}, v.label AS vehicle_label, c.name AS category_name
            FROM parts p JOIN vehicles v ON v.id=p.vehicle_id
            JOIN categories c ON c.id=p.category_id
            WHERE {where} ORDER BY
              CASE p.tier WHEN 'economy' THEN 0 WHEN 'standard' THEN 1
                           WHEN 'premium' THEN 2 ELSE 3 END,
              p.cost""", args)]


@app.get("/api/parts")
def api_parts():
    conds, args = ["1=1"], []
    for key, col in (("vehicle_id", "p.vehicle_id"),
                     ("brand", "p.brand"), ("coated", "p.coated"),
                     ("position", "p.position")):
        v = request.args.get(key)
        if v:
            conds.append(f"{col} = ?")
            args.append(v)
    cids = request.args.get("category_ids")
    if cids:
        ids = [x for x in cids.split(",") if x.strip().isdigit()]
        if ids:
            conds.append("p.category_id IN (%s)" % ",".join("?" * len(ids)))
            args += ids
    else:
        v = request.args.get("category_id")
        if v:
            conds.append("p.category_id = ?")
            args.append(v)
    q = request.args.get("q")
    if q:
        conds.append("(p.brand LIKE ? OR p.part_number LIKE ? OR c.name LIKE ? OR p.specs LIKE ?)")
        args += [f"%{q}%"] * 4
    return jsonify(part_query(" AND ".join(conds), args))


@app.post("/api/parts/fill_prices")
def api_parts_fill_prices():
    """Bulk-fill empty price levels from cost using target GP%.
       Only fills NULL prices, never overwrites existing ones."""
    d = request.get_json(force=True) or {}

    def gp(v):
        try:
            v = float(v)
        except (TypeError, ValueError):
            return None
        return v if 0 < v < 100 else None

    rgp, ggp = gp(d.get("retail_gp")), gp(d.get("garage_gp"))
    if rgp is None and ggp is None:
        return jsonify({"error": "bad gp"}), 400
    conds, args = ["cost IS NOT NULL", "cost > 0"], []
    if d.get("vehicle_id"):
        conds.append("vehicle_id = ?")
        args.append(d["vehicle_id"])
    if d.get("category_id"):
        conds.append("category_id = ?")
        args.append(d["category_id"])
    nulls = []
    if rgp is not None:
        nulls.append("price_retail IS NULL")
    if ggp is not None:
        nulls.append("price_garage IS NULL")
    db = get_db()
    n = db.execute(
        f"SELECT COUNT(*) AS c FROM parts WHERE {' AND '.join(conds)} AND ({' OR '.join(nulls)})",
        args).fetchone()["c"]
    sets, sargs = [], []
    if rgp is not None:
        sets.append("price_retail = CASE WHEN price_retail IS NULL "
                    "THEN ROUND(cost/(1-(?/100.0)),2) ELSE price_retail END")
        sargs.append(rgp)
    if ggp is not None:
        sets.append("price_garage = CASE WHEN price_garage IS NULL "
                    "THEN ROUND(cost/(1-(?/100.0)),2) ELSE price_garage END")
        sargs.append(ggp)
    db.execute(f"UPDATE parts SET {', '.join(sets)} WHERE {' AND '.join(conds)}",
               sargs + args)
    db.commit()
    return jsonify({"updated": n})


@app.get("/api/parts/<int:pid>")
def api_part_one(pid):
    db = get_db()
    r = db.execute(
        f"SELECT {PART_COLS}, v.label AS vehicle_label, c.name AS category_name "
        "FROM parts p JOIN vehicles v ON v.id=p.vehicle_id "
        "JOIN categories c ON c.id=p.category_id WHERE p.id=?", (pid,)).fetchone()
    if not r:
        return jsonify({"error": "not found"}), 404
    return jsonify(row2dict(r))


@app.get("/api/parts/<int:pid>/alternates")
def api_part_alternates(pid):
    """互换件: same OEM number (cross-brand interchange) + same vehicle+category."""
    db = get_db()
    me = db.execute(f"SELECT {PART_COLS} FROM parts p WHERE p.id=?", (pid,)).fetchone()
    if not me:
        return jsonify({"error": "not found"}), 404
    me = row2dict(me)
    by_oem = part_query("p.oem_number = ? AND p.id != ?",
                        (me["oem_number"], pid)) if me.get("oem_number") else []
    by_app = part_query("p.vehicle_id = ? AND p.category_id = ? AND p.id != ?",
                        (me["vehicle_id"], me["category_id"], pid))
    return jsonify({"part": me, "by_oem": by_oem, "by_application": by_app})


# ---------- paste-to-parse: 供应商原文粘贴导入 ----------
import re as _re

_PARSE_BRANDS = ["CBK", "CTR", "Dorman", "ULTRA", "Brembo", "Wagner", "Moog",
                 "Mevotech", "NGK", "Denso", "Bosch", "ACDelco", "Motorcraft",
                 "Monroe", "KYB", "Gates", "Dayco", "SKF", "Timken", "Raybestos",
                 "Centric", "Power Stop", "Ultra-Power", "Promax", "Sidem",
                 "Carquest", "DieHard", "Exide", "Agna", "Bestbuy", "QAP",
                 "CMX", "Unity", "Profusion", "INROBLE", "Bremsen", "ProMax",
                 "Autologix"]
# 配件安装位置（与配件管理下拉一致）
_KNOWN_POSITIONS = ("Front", "Rear", "Left", "Right",
                    "Front Left", "Front Right", "Rear Left", "Rear Right")
_PARSE_SELLERS = ["CBK International Inc", "Groupe Monaco-JAR", "CARQUEST", "NAPA",
                  "Transbec", "Transit Inc", "Bestbuy", "Auto-Kool", "Agna",
                  "ALTROM",
                  "1 800 Radiator and AC", "Autolectra Inc"]
_PARSE_CATS = [
    # ---- 刹车 ----
    ("brake pad wear sensor", "刹车片感应线"), ("wear sensor", "刹车片感应线"),
    ("brake pad", "刹车片"), ("pad set", "刹车片"), ("ceramic pads", "刹车片"),
    ("ceramic", "刹车片"),
    ("brake caliper", "刹车卡钳"), ("caliper", "刹车卡钳"),
    ("brake shoe", "刹车蹄片"), ("shoe", "刹车蹄片"),
    ("brake rotor", "刹车盘"), ("brake disc", "刹车盘"), ("disc brake", "刹车盘"),
    ("rotor", "刹车盘"),
    ("brake hardware", "刹车附件包"), ("hardware kit", "刹车附件包"),
    ("brake hose", "刹车油管"), ("hydraulic hose", "刹车油管"),
    ("brake drum", "刹车鼓"), ("drum", "刹车鼓"),
    ("pedal pad", "刹车踏板垫"),
    # ---- 悬挂转向 ----
    ("control arm bushing", "下摆臂衬套"),
    ("control arm", "下摆臂"), ("contrl arm", "下摆臂"), ("bras de suspension", "下摆臂"),
    ("ball joint", "下球头"),
    ("inner tie rod", "内拉杆"),
    ("tie rod", "外拉杆球头"),
    ("stabilizer bar link", "平衡杆球头"), ("sway bar link", "平衡杆球头"),
    ("stabilizer bar bushing", "平衡杆衬套"), ("sway bar bushing", "平衡杆衬套"),
    ("shock", "减震器"), ("strut", "减震器"),
    ("coil spring", "弹簧"),
    ("wheel bearing", "轮毂轴承"), ("hub assembly", "轮毂轴承"),
    ("hub bearing", "轮毂轴承"), ("bearing", "轮毂轴承"),
    # ---- 排气 ----
    ("catalytic converter", "三元催化器"),
    ("exhaust manifold", "排气歧管"), ("intake manifold", "进气歧管"),
    ("manifold", "排气歧管"),
    ("muffler", "消音器"),
    ("resonator", "共振器"),
    ("exhaust gasket", "排气垫片"), ("flange gasket", "排气垫片"),
    ("exhaust pipe", "排气管"),
    ("hanger", "排气吊耳"), ("insulator", "排气吊耳"),
    ("exhaust bolt", "排气螺丝"), ("exhaust nut", "排气螺丝"),
    ("exhaust spring", "排气螺丝"),
    # ---- 滤清/点火/保养 ----
    ("cabin air filter", "空调滤芯"), ("cabin filter", "空调滤芯"),
    ("oil filter", "机油滤芯"),
    ("air filter", "空气滤芯"),
    ("fuel filter", "燃油滤芯"),
    ("filter", "滤芯"),
    ("spark plug", "火花塞"),
    ("ignition coil", "点火线圈"),
    # ---- 发动机 ----
    ("alternator", "发电机"),
    ("starter", "起动机"),
    ("timing belt", "正时皮带"),
    ("serpentine belt", "皮带"), ("drive belt", "皮带"), ("belt", "皮带"),
    ("water pump", "水泵"),
    ("thermostat", "节温器"),
    # ---- 空调 ----
    ("compressor", "空调压缩机"),
    ("blower motor", "鼓风机电机"),
    ("condenser", "冷凝器"),
    # ---- 电气 ----
    ("battery", "电瓶"), ("batterie", "电瓶"),
    ("wheel speed sensor", "ABS传感器"), ("abs sensor", "ABS传感器"),
    ("sensor", "传感器"), ("capteur", "传感器"),
    # ---- 传动 ----
    ("cv axle", "半轴"), ("axle shaft", "半轴"), ("axle", "半轴"),
]
_PIPE_HDR = _re.compile(
    r"^\s*([^|\n]+?)\s*\|\s*([A-Za-z0-9][A-Za-z0-9\-/]*)\s*\|\s*([^|\n]+?)\s*$")
_MAIN_DETAIL = _re.compile(
    r"(?i)^\s*(mfr\s*code|mfrlabel|note|position|yearrange|transmission\w*)\s*:")
# UI noise glued into pasted text (Bestbuy portal artifacts)
_UI_JUNK = ("Buyer's Guide", "Interchange", "Discrepancy", "Lost Sale",
            "Click to see the Shadow Part Types for this Part Type.",
            "Show All", "Clear Filters", "Cart", "Buy Now", "Order Qty:",
            "Add To Cart", "Add to new order",
            "You can see other warehouses availability by changing warehouse",
            "on your \"New Order\" page.")


def _clean_line(s):
    for j in _UI_JUNK:
        s = s.replace(j, "")
    return s.strip(" -|")


def _new_parsed(seller_hint):
    return {"brand": None, "part_number": None, "category_raw": None,
            "category_suggest": None, "specs": None, "years": None,
            "per_veh": None, "region": None, "seller": seller_hint,
            "fitment_notes": None, "cost": None, "stock_note": None,
            "position": None, "coated": None,
            "alternates": [], "superseded": [], "drivetrains": [],
            "_specs_bits": [], "_blob_low": "", "_in_fit": False,
            "_apps_bits": [], "_in_apps": False}


def _finalize_part(d):
    if d["_specs_bits"]:
        d["specs"] = "; ".join(d["_specs_bits"])
    # coated/uncoated 自动识别（specs 里写了就不用手动选）
    if not d["coated"]:
        blob = (d["specs"] or "") + " " + d["_blob_low"]
        if _re.search(r"(?i)\buncoated\b", blob):
            d["coated"] = "uncoated"
        elif _re.search(r"(?i)\bcoated\b", blob):
            d["coated"] = "coated"
    notes = []
    if d["years"]:
        notes.append("年份 " + d["years"])
    if d["per_veh"]:
        notes.append("每车 " + d["per_veh"] + " 件")
    if d["region"]:
        notes.append("地区 " + d["region"])
    if d["drivetrains"]:
        notes.append("驱动 " + "/".join(d["drivetrains"]))
    # Transit Applications 表：适配车型
    if d["_apps_bits"]:
        notes.append("适用: " + "; ".join(d["_apps_bits"]))
    if d["alternates"]:
        notes.append("互换: " + "; ".join(
            "%s（%s，现货%s，$%s）" % (a["part_number"], a["brand_hint"],
             a["on_hand"] or "?", a["sell"] or "?") for a in d["alternates"]))
    if d["superseded"]:
        notes.append("被替代: " + "; ".join(
            "%s（%s）" % (s["part_number"], s["brand_hint"]) for s in d["superseded"]))
    if notes:
        d["fitment_notes"] = "; ".join(notes)
    if d["brand"] and d["brand"].upper() in ("TRANSBEC", "TRB"):
        # Transbec 自有品牌：Manufacturer 写的是自己，真正品牌在描述里
        _blob_up = (d["specs"] or "").upper()
        for _hb in ("BREMSEN", "PROFUSION"):
            if _hb in _blob_up:
                d["brand"] = _hb.title()
                break
    blob_low = " ".join(x for x in [d["category_raw"] or "", d["specs"] or ""]).lower()
    # 标题（第一段规格）最准，先用标题匹配；标题无命中再用全文
    # （备注里的 "Single Piston Calipers" 是适用说明，不能决定品类）
    title_low = (d["specs"] or "").split(";")[0].strip().lower()
    # 标题里找位置（如 "APEC Front Brake Rotor Vented" → Front）
    if not d["position"]:
        _pm = _re.search(r"(?i)\b(front|rear)\s+(left|right)\b|\b(front|rear|left|right)\b", title_low)
        if _pm:
            _words = [w for w in _pm.groups() if w]
            d["position"] = " ".join(w.capitalize() for w in _words)
    for kw, cat in _PARSE_CATS:
        if kw in title_low:
            d["category_suggest"] = cat
            break
    if not d["category_suggest"]:
        for kw, cat in _PARSE_CATS:
            if kw in blob_low:
                d["category_suggest"] = cat
                break
    if not d["category_suggest"]:
        for kw, cat in _PARSE_CATS:
            if kw in d["_blob_low"]:
                d["category_suggest"] = cat
                break
    d.pop("_specs_bits", None)
    d.pop("_blob_low", None)
    d.pop("_in_fit", None)
    d.pop("_in_apps", None)
    d.pop("_apps_bits", None)
    return d


def _generic_extract(lines, seller_hint):
    """通用兜底提取：未知供应商格式时，打分找出最像件号/价格/位置的候选。
    目标：件号和价格必须尽量对，品类/品牌尽力而为，用户在预览里确认。"""
    import re as _re2
    cur = _new_parsed(seller_hint)
    text = "\n".join(lines)

    # ---- 件号：给所有 token 打分 ----
    best_pn, best_score = None, -1
    seen = set()
    for s in lines:
        for tok in _re2.findall(r"[A-Za-z0-9][A-Za-z0-9\-/\.]*[A-Za-z0-9]", s):
            t = tok.strip(".,;:")
            if len(t) < 5 or t.upper() in seen:
                continue
            seen.add(t.upper())
            low = t.lower()
            # 排除：年份、纯价格、常见噪音词
            if _re2.match(r"^(19|20)\d{2}$", t):
                continue
            if _re2.match(r"^\d{4}\s*[-–]\s*\d{4}$", t):
                continue
            if low in ("price", "stock", "order", "cart", "total", "quantity",
                       "available", "warehouse", "product", "years", "make",
                       "model", "notes", "applications"):
                continue
            has_letter = bool(_re2.search(r"[A-Za-z]", t))
            has_digit = bool(_re2.search(r"\d", t))
            score = 0
            if has_letter and has_digit:
                score += 10
            elif has_letter:
                score += 2
            else:
                # 纯数字：6位以上才可能是件号
                if len(t) < 6 or not _re2.search(r"[A-Z]", s):
                    continue
                score += 3
            if "-" in t:
                score += 3
            if t.isupper():
                score += 2
            if 8 <= len(t) <= 16:
                score += 2
            # 紧邻件号关键词加分
            idx = s.lower().find(low)
            ctx = s[max(0, idx-20):idx].lower()
            if _re2.search(r"(part|product|item|sku|pn|#)\s*[#:]?\s*$", ctx):
                score += 8
            if score > best_score:
                best_score, best_pn = score, t
    if best_pn:
        cur["part_number"] = best_pn

    # ---- 价格：找所有价格，优先带 price/sell 标签的，否则取最低 ----
    prices = []  # (value, labeled)
    for s in lines:
        ls = s.lower()
        labeled = bool(_re2.search(r"(sell|your|our|net|price|cost)\b", ls))
        for m in _re2.finditer(r"\$?\s*([\d,]+\.\d{2})\s*\$?", s):
            try:
                v = float(m.group(1).replace(",", ""))
            except ValueError:
                continue
            if v <= 0 or v > 100000:
                continue
            # 排除年份区间如 2011-2016
            if _re2.search(r"(19|20)\d{2}\s*[-–]", s[:m.start()][-8:]):
                continue
            prices.append((v, labeled))
    if prices:
        labeled_prices = [v for v, lb in prices if lb]
        cur["cost"] = min(labeled_prices) if labeled_prices else min(v for v, _ in prices)

    # ---- 位置：Front/Rear/Left/Right 组合 ----
    m = _re2.search(r"(?i)\bposition\s*[:\-]?\s*(front|rear|left|right)"
                    r"(\s+(front|rear|left|right))?\b", text)
    if m:
        words = [w for w in (m.group(1), m.group(3)) if w]
        cur["position"] = " ".join(w.capitalize() for w in words)
    else:
        # 无 Position 标签时，从所有行找独立的方向词
        for s in lines:
            found = _re2.findall(r"(?i)\b(front|rear|left|right)\b", s)
            if found:
                # 去重保序
                uniq = list(dict.fromkeys(w.capitalize() for w in found))
                cur["position"] = " ".join(uniq[:2])
                break

    # ---- 品牌：已知品牌列表 ----
    for b in _PARSE_BRANDS:
        if _re2.search(r"(?i)\b" + _re2.escape(b) + r"\b", text):
            cur["brand"] = b
            break

    # ---- 标题 → specs（首个有意义的行）----
    for s in lines:
        ls = s.lower()
        if (len(s) >= 4 and _re2.search(r"[A-Za-z]{3,}", s)
                and not _re2.search(r"(price|stock|availab|warehouse|product\s*#|"
                                    r"applications|years\s+make)", ls)):
            cur["_specs_bits"].append(s.strip())
            break
    cur["_blob_low"] = text.lower()
    # 抓到的关键信息也写入备注，方便用户复制校对
    _found = []
    if cur["part_number"]:
        _found.append("件号=" + cur["part_number"])
    if cur["cost"] is not None:
        _found.append("价格=" + str(cur["cost"]))
    if cur["position"]:
        _found.append("位置=" + cur["position"])
    if cur["brand"]:
        _found.append("品牌=" + cur["brand"])
    if _found:
        cur["_specs_bits"].append("[自动识别] " + "；".join(_found))
    return cur


def parse_supplier_text(text):
    raw = (text or "").splitlines()
    lines = [_clean_line(l.strip()) for l in raw]
    lines = [l for l in lines if l]
    warn_all = []
    vehicle_suggest = None
    if lines:
        m = _re.search(r"(\d{4})\s+([A-Za-z]+)\s+([A-Za-z0-9\-]+)", lines[0])
        if m:
            vehicle_suggest = "%s %s %s" % (m.group(1), m.group(2), m.group(3))
    if not vehicle_suggest:
        # scan all lines: "2012-2014 Honda CR-V" or Transbec-style "16-12 HON CR-V"
        for s in lines:
            m = _re.search(r"\b((?:19|20)\d{2}\s*[-–~]\s*(?:19|20)?\d{2}\s+[A-Za-z][\w\.\-& ]+)$", s)
            if m:
                vehicle_suggest = m.group(1).strip()
                break
            m = _re.search(r"\b(\d{2})\s*[-–]\s*(\d{2})\s+([A-Za-z][\w\.\-& ]+)$", s)
            if m:
                lo, hi = sorted((2000 + int(m.group(1)), 2000 + int(m.group(2))))
                vehicle_suggest = "%d-%d %s" % (lo, hi, m.group(3).strip())
                break
    low_all = "\n".join(lines).lower()
    seller_hint = None
    for sname in _PARSE_SELLERS:
        if sname.lower() in low_all:
            seller_hint = sname
            break
    if "bestbuy" in low_all and not seller_hint:
        seller_hint = "Bestbuy"
    if not seller_hint and "cbk" in low_all:
        seller_hint = "CBK International Inc"

    parts = []
    cur = None
    section = None          # None | "alt" | "sup"
    item_buf = None
    pending_price = False   # previous line was "Sell Price"/"Your Price" (price on next line)
    skip_lines = set()      # 已被消费的行号（如 Note 标签的下一行）

    def push_cur():
        if cur and cur["part_number"]:
            parts.append(_finalize_part(cur))

    def is_main_header_ahead(idx):
        for j in range(idx + 1, min(idx + 9, len(lines))):
            lj = lines[j].lower()
            if _MAIN_DETAIL.match(lines[j]):
                return True
            if _PIPE_HDR.match(lines[j]) or lj in ("alternate parts", "superceded parts"):
                break
        return False

    for i, s in enumerate(lines):
        if not s or i in skip_lines:
            continue
        ls = s.lower()
        if ls == "note":
            # Agna 版式："Note" 独占一行，下一行是内容
            if cur is None:
                cur = _new_parsed(seller_hint)
                cur["_blob_low"] = low_all
            if i + 1 < len(lines):
                _nl = lines[i + 1].strip()
                if _nl and len(_nl) <= 200:
                    cur["_specs_bits"].append(_nl)
                skip_lines.add(i + 1)
            continue
        if ls == "alternate parts":
            section = "alt"
            item_buf = None
            continue
        if ls == "superceded parts":
            section = "sup"
            item_buf = None
            continue
        ph = _PIPE_HDR.match(s)
        if section in ("alt", "sup"):
            if ph and not is_main_header_ahead(i):
                item_buf = {"brand_hint": ph.group(1).strip(),
                            "part_number": ph.group(2).strip(),
                            "label": ph.group(3).strip(),
                            "on_hand": None, "sell": None}
                (cur["alternates"] if section == "alt"
                 else cur["superseded"]).append(item_buf)
                continue
            if ph and is_main_header_ahead(i):
                section = None  # fall through to main-part handling
            elif item_buf:
                m2 = _re.search(r"on hand\s*:\s*(\d+)", s, _re.I)
                if m2:
                    item_buf["on_hand"] = m2.group(1)
                m2 = _re.search(r"sell\s*:\s*\$?([\d.]+)", s, _re.I)
                if m2:
                    item_buf["sell"] = m2.group(1)
                continue
            else:
                continue
        # ---- main-part area ----
        if ph:
            push_cur()
            cur = _new_parsed(seller_hint)
            cur["_blob_low"] = low_all
            cur["brand"] = ph.group(1).strip()
            cur["part_number"] = ph.group(2).strip()
            cur["category_raw"] = ph.group(3).strip()
            continue
        if cur is None:
            cur = _new_parsed(seller_hint)
            cur["_blob_low"] = low_all
        # Nexpart "Additional Fitments" 章节：随后几行的 AWD/FWD/RWD/4WD 记入适用说明
        if ls == "additional fitments":
            cur["_in_fit"] = True
            continue
        # Transit 网站 "Applications" 表：Years/Make/Model/Notes，多行适配车型
        if ls == "applications":
            cur["_in_apps"] = True
            continue
        if cur.get("_in_apps"):
            # 表头行跳过
            if _re.match(r"(?i)^years\s+make\s+model", s):
                continue
            # 数据行：2011-2016 Chrysler Town & Country (tab 或空格分隔)
            m = _re.match(r"^(\d{4}\s*[-–]\s*\d{4})\s+(.+)$", s)
            if m:
                years, rest = m.group(1).strip(), m.group(2).strip()
                # rest 按 tab 切分：Make, Model, Notes
                cells = [c.strip() for c in _re.split(r"\t+", rest) if c.strip()]
                if len(cells) >= 2:
                    app_str = f"{years} {' '.join(cells[:2])}"
                    if cells[2:]:
                        app_str += " (" + " ".join(cells[2:]) + ")"
                    cur["_apps_bits"].append(app_str)
                elif cells:
                    cur["_apps_bits"].append(f"{years} {' '.join(cells)}")
                continue
            # 空行或非数据行则退出
            if not s.strip() or _re.match(r"(?i)^(price|availability|product\s*#)", s):
                cur["_in_apps"] = False
            else:
                # 可能是 Model 换行，拼到上一条
                if cur["_apps_bits"] and len(s.strip()) < 60:
                    cur["_apps_bits"][-1] += " " + s.strip()
                continue
        if cur["_in_fit"]:
            if _re.match(r"(?i)^(AWD|FWD|RWD|4WD)$", s):
                if s.upper() not in cur["drivetrains"]:
                    cur["drivetrains"].append(s.upper())
                continue
            cur["_in_fit"] = False
        m = _re.match(r"(?i)^\s*(?:product\s*#|part\s*(?:#|no\.?)|p/?n)\s*[:\-]?\s*([A-Za-z0-9][A-Za-z0-9\-/]*(?:\s+[A-Za-z0-9][A-Za-z0-9\-/]*)?)", s)
        if m:
            if cur["part_number"]:
                push_cur()
                cur = _new_parsed(seller_hint)
                cur["_blob_low"] = low_all
            cur["part_number"] = m.group(1).strip().rstrip(",;")
            continue
        # Transbec-style: part number alone on its own line (e.g. "CP5183", "34349")
        m = _re.match(r"^([A-Z]{1,4}\d[\w\-\./]*|\d+[A-Z][\w\-\./]*|\d{5,})$", s)
        if m and len(s) >= 5:
            if cur["part_number"] and cur["cost"] is not None:
                # 新产品（Transbec 多产品粘贴）：已有件号+价格后又出现独立件号
                push_cur()
                cur = _new_parsed(seller_hint)
                cur["_blob_low"] = low_all
            if not cur["part_number"]:
                cur["part_number"] = m.group(1)
            continue
            # "BRAND PN" on one line, e.g. "CBK WH513058"
            m = _re.match(r"^([A-Za-z][\w\-&]*)\s+([A-Z]{1,4}\d[\w\-\./]*|\d+[A-Z][\w\-\./]*)$", s)
            if m and m.group(1).upper() in [b.upper() for b in _PARSE_BRANDS]:
                cur["brand"] = m.group(1)
                cur["part_number"] = m.group(2)
                continue
        handled = False
        m = _re.match(r"(?i)^\s*transmission\w*\s*:\s*(.+)$", s)
        if m:
            # 存成中性英文，客户报价（EN/FR）直接可用；中文 UI 下 specs 本就是供应商原文
            cur["_specs_bits"].append("Transmission: " + m.group(1).strip())
            handled = True
        if not handled:
            for pat in (r"(?i)^\s*mfrlabel\s*:\s*(.+)$",
                        r"(?i)^\s*note\s*:\s*(.+)$",
                        r"(?i)^\s*note\s+([A-Za-z].+)$",
                        r"(?i)^\s*product details\s*:\s*(.+)$",
                        r"(?i)^\s*application\s*:\s*(.+)$"):
                m = _re.match(pat, s)
                if m:
                    cur["_specs_bits"].append(m.group(1).strip())
                    handled = True
                    break
        if not handled:
            # Nexpart "Position: Front Left" → 结构化位置字段；Agna "Position Rear" 无冒号也认
            m = _re.match(r"(?i)^\s*position\s*:?\s*(.+)$", s)
            if m:
                pv = m.group(1).strip()
                if pv in _KNOWN_POSITIONS:
                    cur["position"] = pv
                else:
                    cur["_specs_bits"].append(pv)
                handled = True
        if handled:
            continue
        m = _re.match(r"(?i)^\s*manufacturer\s*:\s*([A-Za-z][\w\.\-&]+)", s)
        if m and not cur["brand"]:
            cur["brand"] = m.group(1).strip()
        # 新格式："Brand: APEC"
        m = _re.match(r"(?i)^\s*brand\s*:\s*([A-Za-z][\w\.\-& ]+?)\s*$", s)
        if m and not cur["brand"]:
            cur["brand"] = m.group(1).strip()
        # 新格式："(2) Qty/Car" → 每车数量
        m = _re.match(r"^\((\d+)\)\s*qty\s*/\s*car", s, _re.I)
        if m and not cur["per_veh"]:
            cur["per_veh"] = m.group(1)
        # 新格式："82 Available" → 库存
        m = _re.match(r"^(\d+)\s+available$", s, _re.I)
        if m and not cur["stock_note"]:
            cur["stock_note"] = "现货 " + m.group(1)
        # 新格式："Superseded By Part Number XXX"
        m = _re.search(r"(?i)superseded\s+by\s+part\s+(?:number\s+)?([A-Za-z0-9][\w\-/]*)", s)
        if m:
            cur["_specs_bits"].append("被替代为 " + m.group(1).strip())
        m = _re.search(r"(?i)\b(?:years|yearrange)\s*:\s*([0-9]{4}\s*[-–]\s*[0-9]{2,4})", s)
        if m:
            cur["years"] = m.group(1).strip()
        m = _re.search(r"(?i)(?:quantity\s+)?per\s+veh\w*\s*:?\s*(\d+)", s)
        if m:
            cur["per_veh"] = m.group(1).strip()
        if cur["years"] or cur["per_veh"]:
            # 本行已处理年份/件数；若同时是纯信息行则跳过后续
            if _re.match(r"(?i)^\s*(?:years|yearrange|per\s+veh)\b", s):
                continue
        m = _re.match(r"(?i)^\s*region\s*:\s*(.+)$", s)
        if m:
            cur["region"] = m.group(1).strip()
            continue
        m = _re.search(r"sell\s*:\s*\$?([\d.,]+)", s, _re.I)
        if not m:
            # Nexpart 同行 "Sell Price $106.51" / "Your Price $27.71"（无冒号）
            m = _re.search(r"(?i)\b(?:sell|your)\s+price\s+\$?([\d,]+(?:\.\d{1,2})?)", s)
        if not m:
            # 新格式："COST $63.70/Each"（取 COST 不取 LIST）
            m = _re.search(r"(?i)\bcost\s+\$?([\d,]+(?:\.\d{1,2})?)", s)
        if m and cur["cost"] is None:
            try:
                cur["cost"] = float(m.group(1).replace(",", ""))
            except ValueError:
                pass
            pending_price = False
        elif ls in ("sell price", "your price"):
            pending_price = True
        elif pending_price:
            m2 = _re.match(r"^\$?([\d.]+)$", s)
            if m2 and cur["cost"] is None:
                try:
                    cur["cost"] = float(m2.group(1))
                except ValueError:
                    pass
            pending_price = False
        # Transit 网站："Price 16.29 $"（$ 在数字后，法式格式）
        if cur["cost"] is None:
            m2 = _re.match(r"(?i)^price\s+([\d,]+(?:\.\d{1,2})?)\s*\$$", s)
            if m2:
                try:
                    cur["cost"] = float(m2.group(1).replace(",", ""))
                except ValueError:
                    pass
        if cur["cost"] is None:
            # Transbec-style: price alone on its own line (e.g. "$98.82")
            m2 = _re.match(r"^\$([\d,]+(?:\.\d{1,2})?)$", s)
            if m2:
                try:
                    cur["cost"] = float(m2.group(1).replace(",", ""))
                except ValueError:
                    pass
        # Agna-style: "CA$28.94" 划线价在前、"CA$16.78" 实价在后，取低者为成本
        m2 = _re.match(r"^CA\$([\d,]+(?:\.\d{1,2})?)$", s)
        if m2:
            try:
                _pv = float(m2.group(1).replace(",", ""))
                if cur["cost"] is None or _pv < cur["cost"]:
                    cur["cost"] = _pv
            except ValueError:
                pass
        if ls in ("available", "in stock"):
            if not cur["stock_note"]:
                cur["stock_note"] = "有货"
            continue
        # Transit 网站："Availability ✅ IN STOCK at Levis Warehouse"
        m = _re.match(r"(?i)^availability\s+.*?in\s+stock\s+at\s+(.+)$", s)
        if m:
            if not cur["stock_note"]:
                cur["stock_note"] = "有货 @" + m.group(1).strip()
            continue
        m = _re.search(r"on hand\s*:\s*(\d+)", s, _re.I)
        if m:
            cur["stock_note"] = (seller_hint or "供应商") + " 现货 " + m.group(1)
        m = _re.search(r"(?i)\bprimary\s+(\d+)", s)
        if m:
            # "Primary 7" 或 Nexpart 同行 "Buy From: Primary 7 Others 73"
            cur["stock_note"] = "主仓现货 " + m.group(1)
        m = _re.search(r"(?i)\bothers\s+(\d+)", s)
        if m:
            cur["stock_note"] = (cur["stock_note"] + "；" if cur["stock_note"] else "") + \
                "其他仓 " + m.group(1)
        m = _re.match(r"^([A-Za-z][\w\.\- ]+?)\s*\((\d+)\)$", s)
        if m and not cur["stock_note"]:
            # Transbec-style: "Chomedey (1)"
            cur["stock_note"] = m.group(1).strip() + " 现货 " + m.group(2)
        m = _re.search(r"(?i)other stores?\(s\)?\s*:\s*(\d+)", s)
        if m:
            cur["stock_note"] = (cur["stock_note"] + "；" if cur["stock_note"] else "") + \
                "其他店 " + m.group(1)
        if not cur["seller"]:
            for sname in _PARSE_SELLERS:
                if sname.lower() in ls:
                    cur["seller"] = sname
                    break
        if not cur["brand"]:
            _bu = [b.upper() for b in _PARSE_BRANDS]
            # 卖家行（如 CBK International Inc）不算品牌，真正的品牌在后面
            _is_seller_line = any(sn.lower() in ls for sn in _PARSE_SELLERS)
            if _is_seller_line:
                pass
            elif s.upper() in _bu:
                cur["brand"] = s.strip()
            else:
                # brand as first word of a header line, e.g. "NGK USA STOCK NUMBERS"
                _w0 = _re.match(r"^([A-Za-z][\w\-&]*)\b", s)
                if _w0 and _w0.group(1).upper() in _bu:
                    cur["brand"] = _w0.group(1)
                elif not cur["part_number"] and "|" not in s and s.isupper():
                    # Nexpart 固定模版：件号出现之前的全大写短行是品牌
                    # （如 TRANSIT / INROBLE INTERNATIONAL）；含品类关键词的不算
                    _ws = s.split()
                    if 2 <= len(s) <= 40 and 1 <= len(_ws) <= 3 \
                            and not _re.search(r"\d", s) \
                            and not any(kw in ls for kw, _c in _PARSE_CATS):
                        cur["brand"] = s.strip()
        # fallback: first description-like lines -> specs
        # (e.g. Transbec "F DISC BRAKE ROTOR. PROFUSION BRAKE DISC")
        if len(cur["_specs_bits"]) < 2 and _re.search(r"[A-Za-z]{2,}", s) \
                and 4 <= len(s) <= 120 \
                and not any(sname.lower() in ls or ls in sname.lower()
                            for sname in _PARSE_SELLERS) \
                and not _re.search(
                    r"(?i)(manufacturer|mfr|seller|vendor|yearrange|years|region|per veh|"
                    r"on hand|primary|others|other stores?|buy from|sold by|sell|price|cost|"
                    r"stock|inventory|cart|buy now|order|qty|quantity|chomedey|^\$|"
                    r"popularity|interchange|buyers?\s+guide|"
                    r"^\d{4}\s|\b(19|20)\d{2}\b|\binc\b)", s):
            cur["_specs_bits"].append(s.strip())
    push_cur()
    # 通用兜底：无结果，或结果缺件号/价格时，用打分提取补全
    _needs_generic = (not parts or
                      all(not p["part_number"] and p["cost"] is None for p in parts) or
                      any(not p["part_number"] or p["cost"] is None for p in parts))
    if _needs_generic:
        g = _generic_extract(lines, seller_hint)
        if g and (g["part_number"] or g["cost"] is not None):
            if not parts:
                parts = [_finalize_part(g)]
            else:
                # 合并：只补缺失的关键字段
                gf = _finalize_part(g)
                for p in parts:
                    if not p["part_number"] and gf["part_number"]:
                        p["part_number"] = gf["part_number"]
                    if p["cost"] is None and gf["cost"] is not None:
                        p["cost"] = gf["cost"]
                    if not p["position"] and gf.get("position"):
                        p["position"] = gf["position"]
                    if not p["brand"] and gf.get("brand"):
                        p["brand"] = gf["brand"]
                    if not p["category_suggest"] and gf.get("category_suggest"):
                        p["category_suggest"] = gf["category_suggest"]
    for n, p in enumerate(parts):
        w = []
        if not p["part_number"]:
            w.append("未识别到件号")
        if not p["brand"]:
            w.append("未识别到品牌，请手动填写")
        if not p["category_suggest"]:
            w.append("未识别到品类，请手动选择")
        warn_all.extend("第%d件：%s" % (n + 1, x) for x in w)
    return {"parts": parts, "warnings": warn_all, "vehicle_suggest": vehicle_suggest}

@app.post("/api/parts/parse")
def api_parts_parse():
    d = request.get_json(force=True) or {}
    r = parse_supplier_text(d.get("text", ""))
    # auto-create suggested categories so the preview dropdown can match them
    db = get_db()
    for p in r["parts"]:
        if p.get("category_suggest"):
            db.execute("INSERT OR IGNORE INTO categories(name) VALUES(?)",
                       (p["category_suggest"],))
    db.commit()
    return jsonify(r)


@app.post("/api/parts/ocr")
def api_parts_ocr():
    """Screenshot OCR: upload a Nexpart listing screenshot, get back text for the parser."""
    f = request.files.get("image")
    if not f:
        return jsonify({"error": "no image"}), 400
    data = f.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        return jsonify({"error": "image too large (max 8MB)"}), 413
    if not data:
        return jsonify({"error": "empty image"}), 400
    import subprocess
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
        tf.write(data)
        path = tf.name
    try:
        try:
            r = subprocess.run(["tesseract", path, "stdout", "-l", "eng"],
                               capture_output=True, text=True, timeout=90)
        except FileNotFoundError:
            return jsonify({"error": "ocr_unavailable",
                            "detail": "tesseract not installed on server"}), 500
        text = (r.stdout or "").strip()
    except subprocess.TimeoutExpired:
        return jsonify({"error": "ocr_timeout"}), 500
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return jsonify({"text": text})


@app.get("/api/backup/export_excel")
@owner_required_api
def api_export_excel():
    """导出 Excel：配件 / 报价 / 报价明细 / 客户 / 车辆，多个 sheet。"""
    try:
        from openpyxl import Workbook
    except ImportError:
        return jsonify({"error": "openpyxl not installed",
                        "detail": "pip install -r requirements.txt"}), 500
    import tempfile
    db = get_db()
    wb = Workbook()
    wb.remove(wb.active)

    def _add(title, cols, rows):
        ws = wb.create_sheet(title)
        ws.append([c[0] for c in cols])
        for r in rows:
            ws.append([r.get(c[1]) for c in cols])
        for i, c in enumerate(cols, 1):
            mx = len(str(c[0]))
            for r in rows[:1000]:
                v = r.get(c[1])
                if v is not None:
                    mx = max(mx, len(str(v)))
            ws.column_dimensions[ws.cell(1, i).column_letter].width = min(mx + 2, 55)
        ws.freeze_panes = "A2"

    _parts_rows = []
    for r in db.execute(
            """SELECT v.label AS vehicle, c.name AS category, p.brand, p.part_number,
                      p.specs, p.coated, p.position, p.tier, p.cost,
                      p.price_retail, p.price_garage, p.seller, p.stock_note,
                      p.oem_number, p.fitment_notes
               FROM parts p LEFT JOIN vehicles v ON v.id=p.vehicle_id
                            LEFT JOIN categories c ON c.id=p.category_id
               ORDER BY v.label, c.name, p.part_number"""):
        d = row2dict(r)
        d["category"] = CAT_EN.get(d["category"], d["category"])
        _parts_rows.append(d)
    _add("Parts", [
        ("Vehicle", "vehicle"), ("Category", "category"), ("Brand", "brand"),
        ("Part #", "part_number"), ("Specs", "specs"), ("Coating", "coated"),
        ("Position", "position"), ("Tier", "tier"), ("Cost", "cost"),
        ("Retail price", "price_retail"), ("Garage price", "price_garage"),
        ("Supplier", "seller"), ("Stock note", "stock_note"), ("OEM #", "oem_number"),
        ("Fitment notes", "fitment_notes")],
        _parts_rows)

    _add("Quotes", [
        ("ID", "id"), ("Date", "created_at"), ("Customer", "customer_name"),
        ("Type", "customer_type"), ("Vehicle", "vehicle_text"), ("VIN", "vin"),
        ("Status", "status"), ("Lost reason", "lost_reason"), ("Staff", "staff"),
        ("Notes", "notes")],
        [row2dict(r) for r in db.execute(
            """SELECT q.id, q.created_at, q.customer_name, q.customer_type,
                      q.vehicle_text, q.vin, q.status, q.lost_reason, s.name AS staff,
                      q.notes
               FROM quotes q LEFT JOIN staff s ON s.id=q.staff_id
               ORDER BY q.id DESC""")])

    _add("Quote items", [
        ("Quote ID", "quote_id"), ("Date", "created_at"), ("Brand", "brand"),
        ("Part #", "part_number"), ("Specs", "specs"), ("Qty", "qty"),
        ("Cost", "cost"), ("Quoted price", "quoted_price")],
        [row2dict(r) for r in db.execute(
            """SELECT qi.quote_id, q.created_at, qi.brand, qi.part_number, qi.specs,
                      qi.qty, qi.cost, qi.quoted_price
               FROM quote_items qi JOIN quotes q ON q.id=qi.quote_id
               ORDER BY qi.quote_id DESC, qi.id""")])

    _add("Customers", [
        ("Name", "name"), ("Phone", "phone"), ("Type", "ctype"), ("Notes", "notes")],
        [row2dict(r) for r in db.execute(
            "SELECT name, phone, ctype, notes FROM customers ORDER BY name")])

    _add("Vehicles", [
        ("Label", "label"), ("Year", "year"), ("Drivetrain", "drivetrain"), ("Fuel", "fuel")],
        [row2dict(r) for r in db.execute(
            "SELECT label, year, drivetrain, fuel FROM vehicles ORDER BY label")])

    fd, tmp = tempfile.mkstemp(prefix="qb-excel-", suffix=".xlsx")
    os.close(fd)
    try:
        wb.save(tmp)

        @after_this_request
        def _cleanup(resp):
            try:
                os.unlink(tmp)
            except OSError:
                pass
            return resp

        fname = "quotebook-export-%s.xlsx" % datetime.now().strftime("%Y%m%d")
        return send_file(tmp, as_attachment=True, download_name=fname,
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


@app.get("/api/backup/export")
@owner_required_api
def api_backup_export():
    """Download a consistent snapshot of the whole database (VACUUM INTO temp file)."""
    import tempfile
    fd, tmp = tempfile.mkstemp(prefix="qb-backup-", suffix=".db")
    os.close(fd)
    try:
        get_db().execute("VACUUM INTO ?", (tmp,))

        @after_this_request
        def _cleanup(resp):
            try:
                os.unlink(tmp)
            except OSError:
                pass
            return resp

        fname = "quotebook-backup-%s.db" % datetime.now().strftime("%Y%m%d")
        return send_file(tmp, as_attachment=True, download_name=fname)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


_BACKUP_REQUIRED_TABLES = {"categories", "customers", "parts", "quote_items",
                            "quotes", "staff", "vehicles"}


@app.post("/api/backup/restore")
@owner_required_api
def api_backup_restore():
    """Restore the database from an uploaded backup file. Old DB is rotated aside."""
    import tempfile
    f = request.files.get("backup")
    if not f:
        return jsonify({"error": "no file"}), 400
    fd, tmp = tempfile.mkstemp(prefix="qb-restore-", suffix=".db")
    try:
        # stream upload with a sanity cap (512MB)
        size = 0
        with os.fdopen(fd, "wb") as fh:
            while True:
                chunk = f.stream.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > 512 * 1024 * 1024:
                    return jsonify({"error": "file too large"}), 413
                fh.write(chunk)
        # validate: must be a readable SQLite DB with our tables
        try:
            con = sqlite3.connect(tmp)
            try:
                tables = {r[0] for r in
                          con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            finally:
                con.close()
        except sqlite3.Error:
            return jsonify({"error": "not a valid database file"}), 400
        if not _BACKUP_REQUIRED_TABLES.issubset(tables):
            return jsonify({"error": "not a QuoteBook backup"}), 400
        # rotate current DB aside, then swap in the upload
        data_dir = os.path.dirname(DB_PATH)
        bdir = os.path.join(data_dir, "backups")
        os.makedirs(bdir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        if os.path.exists(DB_PATH):
            if hasattr(g, "db"):
                try:
                    g.db.close()
                except Exception:
                    pass
                g.pop("db", None)
            os.rename(DB_PATH, os.path.join(bdir, "quotebook-%s.db" % ts))
            for ext in ("-wal", "-shm", "-journal"):
                p = DB_PATH + ext
                if os.path.exists(p):
                    os.rename(p, os.path.join(bdir, "quotebook-%s.db%s" % (ts, ext)))
        os.rename(tmp, DB_PATH)
        tmp = None  # now live; don't delete
        # prune: keep the 10 most recent rotated backups
        olds = sorted(f for f in os.listdir(bdir) if f.startswith("quotebook-"))
        for old in olds[:-10]:
            try:
                os.unlink(os.path.join(bdir, old))
            except OSError:
                pass
        return jsonify({"ok": True})
    finally:
        if tmp:
            try:
                os.unlink(tmp)
            except OSError:
                pass


@app.post("/api/categories")
def api_category_add():
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    db = get_db()
    # 大小写不敏感去重：已有则直接返回
    r = db.execute("SELECT id, name FROM categories WHERE LOWER(name)=LOWER(?)",
                   (name,)).fetchone()
    if r:
        return jsonify(row2dict(r)), 200
    db.execute("INSERT INTO categories(name) VALUES(?)", (name,))
    db.commit()
    r = db.execute("SELECT id, name FROM categories WHERE name=?", (name,)).fetchone()
    return jsonify(row2dict(r)), 201


# ---------- customers ----------
@app.get("/api/customers")
def api_customer_list():
    q = (request.args.get("q") or "").strip()
    db = get_db()
    if q:
        rows = db.execute(
            "SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name LIMIT 50",
            (f"%{q}%", f"%{q}%"))
    else:
        rows = db.execute("SELECT * FROM customers ORDER BY id DESC LIMIT 50")
    return jsonify([row2dict(r) for r in rows])


@app.post("/api/customers")
def api_customer_add():
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    ctype = d.get("ctype") if d.get("ctype") in ("retail", "garage") else "retail"
    db = get_db()
    cur = db.execute("INSERT INTO customers(name,phone,ctype,notes) VALUES(?,?,?,?)",
                     (name, (d.get("phone") or "").strip() or None, ctype, d.get("notes")))
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.put("/api/customers/<int:cid>")
def api_customer_update(cid):
    d = request.get_json(force=True) or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name required"}), 400
    ctype = d.get("ctype") if d.get("ctype") in ("retail", "garage") else "retail"
    db = get_db()
    cur = db.execute("UPDATE customers SET name=?, phone=?, ctype=?, notes=? WHERE id=?",
                     (name, (d.get("phone") or "").strip() or None, ctype,
                      (d.get("notes") or "").strip() or None, cid))
    db.commit()
    if not cur.rowcount:
        return jsonify({"error": "not found"}), 404
    return jsonify({"ok": True})


@app.delete("/api/customers/<int:cid>")
def api_customer_delete(cid):
    # 历史报价保留 customer_name 快照；先把引用置空再删（外键约束）
    db = get_db()
    db.execute("UPDATE quotes SET customer_id=NULL WHERE customer_id=?", (cid,))
    cur = db.execute("DELETE FROM customers WHERE id=?", (cid,))
    db.commit()
    if not cur.rowcount:
        return jsonify({"error": "not found"}), 404
    return jsonify({"ok": True})


@app.get("/api/parts/filter_options")
def api_filter_options():
    db = get_db()
    vid = request.args.get("vehicle_id")
    cid = request.args.get("category_id")
    cids = request.args.get("category_ids")
    ids = [x for x in (cids or "").split(",") if x.strip().isdigit()]
    if cid and not ids:
        ids = [cid]
    if not vid or not ids:
        return jsonify({"brands": [], "coated": [], "positions": []})
    brands = [r[0] for r in db.execute(
        "SELECT DISTINCT brand FROM parts WHERE vehicle_id=? AND category_id IN (%s) AND brand IS NOT NULL ORDER BY brand"
        % ",".join("?" * len(ids)),
        (vid, *ids))]
    return jsonify({"brands": brands, "coated": ["coated", "uncoated"],
                    "positions": ["Front", "Rear", "Left", "Right",
                                  "Front Left", "Front Right",
                                  "Rear Left", "Rear Right"]})


@app.get("/api/parts/reverse_lookup")
def api_reverse_lookup():
    """件号反查：输入件号 → 适用车型 + 历史报价记录（件号归一化匹配）。"""
    pn = (request.args.get("pn") or "").strip()
    norm = _re.sub(r"[^A-Z0-9]", "", pn.upper())
    if not norm:
        return jsonify({"error": "pn required"}), 400

    def _norm(s):
        return _re.sub(r"[^A-Z0-9]", "", (s or "").upper())

    db = get_db()
    vehicles, seen_v = [], set()
    for r in db.execute(
            """SELECT v.id AS vid, v.label, p.id AS part_id, p.brand, p.part_number,
                      p.specs, p.coated, p.position, p.cost, p.seller
               FROM parts p JOIN vehicles v ON v.id = p.vehicle_id"""):
        d = row2dict(r)
        if _norm(d["part_number"]) == norm and d["vid"] not in seen_v:
            seen_v.add(d["vid"])
            vehicles.append({
                "vehicle_id": d["vid"], "vehicle": d["label"],
                "part_id": d["part_id"], "brand": d["brand"],
                "part_number": d["part_number"], "specs": d["specs"],
                "coated": d["coated"], "position": d["position"],
                "cost": d["cost"], "seller": d["seller"]})
    quotes = []
    for r in db.execute(
            """SELECT q.id AS quote_id, q.created_at, q.customer_name, q.customer_type,
                      q.vehicle_text, q.vin, q.status,
                      qi.qty, qi.quoted_price, qi.brand, qi.part_number, qi.specs
               FROM quote_items qi JOIN quotes q ON q.id = qi.quote_id
               ORDER BY q.created_at DESC LIMIT 200"""):
        d = row2dict(r)
        if _norm(d["part_number"]) == norm:
            quotes.append({
                "quote_id": d["quote_id"], "date": (d["created_at"] or "")[:16],
                "customer": d["customer_name"], "customer_type": d["customer_type"],
                "vehicle": d["vehicle_text"], "vin": d["vin"], "status": d["status"],
                "qty": d["qty"], "price": d["quoted_price"],
                "brand": d["brand"], "part_number": d["part_number"]})
            if len(quotes) >= 50:
                break
    return jsonify({"part_number": pn, "vehicles": vehicles, "quotes": quotes})


@app.get("/api/categories/duplicates")
def api_categories_duplicates():
    """找出疑似重复品类：名称归一化（去空格、小写）相同。"""
    db = get_db()
    groups = {}
    for r in db.execute(
            """SELECT c.id, c.name,
                      (SELECT COUNT(*) FROM parts p WHERE p.category_id=c.id) AS n_parts
               FROM categories c ORDER BY c.name"""):
        d = row2dict(r)
        n = (d["name"] or "").strip().lower()
        if not n:
            continue
        g = groups.setdefault(n, {"name": d["name"], "cats": []})
        g["cats"].append({"id": d["id"], "name": d["name"], "n_parts": d["n_parts"]})
    dupes = [g for g in groups.values() if len(g["cats"]) > 1]
    return jsonify({"groups": dupes, "count": len(dupes)})


@app.post("/api/categories/merge")
def api_categories_merge():
    """合并重复品类：保留 keep_id，把配件指过去后删除其他品类。"""
    d = request.get_json(force=True)
    keep_id = d.get("keep_id")
    merge_ids = [i for i in (d.get("merge_ids") or []) if i != keep_id]
    if not keep_id or not merge_ids:
        return jsonify({"error": "keep_id and merge_ids required"}), 400
    db = get_db()
    keep = db.execute("SELECT id FROM categories WHERE id=?", (keep_id,)).fetchone()
    if not keep:
        return jsonify({"error": "keeper not found"}), 404
    ph = ",".join("?" * len(merge_ids))
    n = db.execute(f"SELECT COUNT(*) AS n FROM categories WHERE id IN ({ph})",
                   merge_ids).fetchone()["n"]
    if n != len(merge_ids):
        return jsonify({"error": "some categories not found"}), 404
    db.execute(f"UPDATE parts SET category_id=? WHERE category_id IN ({ph})",
               (keep_id, *merge_ids))
    db.execute(f"DELETE FROM categories WHERE id IN ({ph})", merge_ids)
    db.commit()
    return jsonify({"ok": True, "merged": len(merge_ids)})


@app.get("/api/parts/duplicates")
def api_parts_duplicates():
    """找出疑似重复配件：同车 + 件号归一化（大写、去非字母数字）相同。"""
    def _norm(s):
        return _re.sub(r"[^A-Z0-9]", "", (s or "").upper())

    db = get_db()
    groups = {}
    for r in db.execute(
            """SELECT p.id, p.vehicle_id, v.label AS vehicle, p.brand, p.part_number,
                      p.specs, p.cost, p.seller, p.coated, p.position, p.created_at
               FROM parts p JOIN vehicles v ON v.id = p.vehicle_id
               ORDER BY v.label, p.part_number"""):
        d = row2dict(r)
        n = _norm(d["part_number"])
        if not n:
            continue
        key = (d["vehicle_id"], n)
        g = groups.setdefault(key, {"vehicle_id": d["vehicle_id"],
                                    "vehicle": d["vehicle"],
                                    "part_number": d["part_number"],
                                    "parts": []})
        g["parts"].append({k: d[k] for k in
                           ("id", "brand", "part_number", "specs", "cost",
                            "seller", "coated", "position", "created_at")})
    dupes = [g for g in groups.values() if len(g["parts"]) > 1]
    return jsonify({"groups": dupes, "count": len(dupes)})


@app.post("/api/parts/merge")
def api_parts_merge():
    """合并重复配件：保留 keep_id，把其他 id 的报价项关联指过去后删除。"""
    d = request.get_json(force=True)
    keep_id = d.get("keep_id")
    merge_ids = [i for i in (d.get("merge_ids") or []) if i != keep_id]
    if not keep_id or not merge_ids:
        return jsonify({"error": "keep_id and merge_ids required"}), 400
    db = get_db()
    keep = db.execute("SELECT id, vehicle_id FROM parts WHERE id=?", (keep_id,)).fetchone()
    if not keep:
        return jsonify({"error": "keeper not found"}), 404
    # 安全检查：被合并的必须同车
    ph = ",".join("?" * len(merge_ids))
    others = db.execute(f"SELECT id, vehicle_id FROM parts WHERE id IN ({ph})",
                        merge_ids).fetchall()
    if len(others) != len(merge_ids) or any(o["vehicle_id"] != keep["vehicle_id"] for o in others):
        return jsonify({"error": "parts must belong to the same vehicle"}), 400
    db.execute(f"UPDATE quote_items SET part_id=? WHERE part_id IN ({ph})",
               (keep_id, *merge_ids))
    db.execute(f"DELETE FROM parts WHERE id IN ({ph})", merge_ids)
    db.commit()
    return jsonify({"ok": True, "merged": len(merge_ids)})


@app.post("/api/parts")
def api_part_add():
    d = request.get_json(force=True)
    if not d.get("part_number") or not d.get("vehicle_id") or not d.get("category_id"):
        return jsonify({"error": "vehicle_id, category_id, part_number required"}), 400
    db = get_db()
    cur = db.execute(
        """INSERT INTO parts(vehicle_id,category_id,brand,part_number,specs,coated,
                             position,fitment_notes,tier,cost,stock_note,stock_updated_at,seller,
                             price_retail,price_garage,oem_number)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (d["vehicle_id"], d["category_id"], d.get("brand"), d["part_number"],
         d.get("specs"), d.get("coated"), d.get("position"), d.get("fitment_notes"),
         d.get("tier"), d.get("cost"), d.get("stock_note"), d.get("stock_updated_at"),
         d.get("seller"),
         d.get("price_retail"), d.get("price_garage"), d.get("oem_number")))
    if d.get("stock_note") and not d.get("stock_updated_at"):
        db.execute("UPDATE parts SET stock_updated_at=datetime('now','localtime') WHERE id=?",
                   (cur.lastrowid,))
    # 供应商价格同步
    if d.get("seller") and d.get("cost") is not None:
        sync_supplier_price(db, cur.lastrowid, d["seller"], d["cost"], d.get("stock_note"))
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.put("/api/parts/<int:pid>")
def api_part_update(pid):
    d = request.get_json(force=True)
    fields = ("vehicle_id", "category_id", "brand", "part_number", "specs", "coated",
              "position", "fitment_notes", "tier", "cost", "stock_note", "seller",
              "price_retail", "price_garage", "oem_number")
    sets = [f"{k} = ?" for k in fields if k in d]
    if not sets:
        return jsonify({"error": "nothing to update"}), 400
    vals = [d[k] for k in fields if k in d]
    if "stock_note" in d:
        # stock is a volatile snapshot: bump its timestamp whenever the note changes
        sets.append("stock_updated_at = datetime('now','localtime')")
    db = get_db()
    # 价格变动记审计
    old = None
    if any(k in d for k in ("cost", "price_retail", "price_garage")):
        old = db.execute(
            "SELECT brand, part_number, cost, price_retail, price_garage FROM parts WHERE id=?",
            (pid,)).fetchone()
    db.execute(f"UPDATE parts SET {', '.join(sets)}, updated_at=datetime('now','localtime') WHERE id = ?",
               vals + [pid])
    # 供应商价格同步（带 seller + cost 的更新视为供应商报价）
    _seller = d.get("seller")
    if _seller is None:
        _seller = db.execute("SELECT seller FROM parts WHERE id=?", (pid,)).fetchone()[0]
    if _seller and d.get("cost") is not None:
        sync_supplier_price(db, pid, _seller, d["cost"], d.get("stock_note"))
    db.commit()
    if old:
        chg = []
        for k, lbl in (("cost", "cost"), ("price_retail", "retail"), ("price_garage", "garage")):
            if k in d and d[k] != old[k]:
                chg.append(f"{lbl}: {old[k]} → {d[k]}")
        if chg:
            audit("price_change", "part", pid,
                  f"{old['brand'] or ''} {old['part_number'] or ''}".strip() + " | " + "; ".join(chg))
    return jsonify({"ok": True})


@app.get("/api/parts/<int:pid>/supplier_prices")
def api_part_supplier_prices(pid):
    db = get_db()
    rows = db.execute(
        "SELECT supplier, cost, stock_note, updated_at FROM supplier_prices"
        " WHERE part_id=? ORDER BY cost ASC", (pid,)).fetchall()
    return jsonify([dict(r) for r in rows])


@app.delete("/api/parts/<int:pid>")
@owner_required_api
def api_part_delete(pid):
    db = get_db()
    p = db.execute("SELECT brand, part_number FROM parts WHERE id=?", (pid,)).fetchone()
    db.execute("DELETE FROM parts WHERE id = ?", (pid,))
    db.commit()
    if p:
        audit("delete_part", "part", pid, f"{p['brand'] or ''} {p['part_number'] or ''}".strip())
    return jsonify({"ok": True})


# ---------- quote text ----------
# specs 里可能残留解析器早期版本写入的中文前缀（变速箱），客户报价文本里按目标语言展示；
# 新解析的数据已存成中性英文（Transmission:），此映射只负责兼容历史数据。
_SPEC_ZH_TR = (
    (r"^变速箱\s*", "Transmission: ", "Transmission : "),
)


def _spec_localize(s, lang):
    s = s or ""
    for pat, en, fr in _SPEC_ZH_TR:
        s = _re.sub(pat, en if lang == "en" else fr, s)
    return s


def resolve_items(db, items):
    """Attach part snapshot data to quote line items."""
    out = []
    for it in items:
        p = db.execute(f"SELECT {PART_COLS}, c.name AS category_name FROM parts p "
                       "JOIN categories c ON c.id=p.category_id WHERE p.id=?",
                       (it["part_id"],)).fetchone()
        p = row2dict(p) or {}
        out.append({
            "part_id": it.get("part_id"),
            "tier": p.get("tier") or it.get("tier"),
            "brand": p.get("brand") or it.get("brand"),
            "part_number": p.get("part_number") or it.get("part_number"),
            "specs": p.get("specs") or it.get("specs"),
            "coated": p.get("coated") or it.get("coated"),
            "position": p.get("position") or it.get("position"),
            "category": p.get("category_name"),
            "cost": p.get("cost") if p.get("cost") is not None else it.get("cost"),
            "quoted_price": it.get("quoted_price"),
            "qty": int(it.get("qty") or 1),
        })
    return out


def quote_text_en(d, items, qid):
    lines = [f"{STORE['name']} — QUOTE",
             f"Date: {d.get('date_str','')}   |   Quote #{qid or '—'}",
             f"Customer: {d.get('customer_name','')} ({'garage account' if d.get('customer_type')=='garage' else 'retail'})",
             f"Vehicle: {d.get('vehicle_text','')}" + (f"   VIN: {d['vin']}" if d.get("vin") else ""),
             ""]
    total = 0
    for i, it in enumerate(items, 1):
        cat = CAT_EN.get(it["category"], it["category"] or "Part")
        # 客户版只显示位置和涂层，不显示内部规格（太长太乱）
        attrs = ", ".join(a for a in [it["coated"],
                                      {"L": "Left", "R": "Right"}.get(it["position"],
                                                                      it["position"])] if a)
        price = it["quoted_price"] or 0
        line_total = price * it["qty"]
        total += line_total
        lines.append(f"{i}) {cat} — {it['brand'] or ''}, P/N {it['part_number']}"
                     f"{' (' + attrs + ')' if attrs else ''} x{it['qty']} — CAD {line_total:,.2f}")
    lines += ["", f"Total: CAD {total:,.2f}",
              "Prices in CAD, taxes extra. Quote valid 7 days.",
              f"WhatsApp: {STORE['phone']} | {STORE['addr']}"]
    return "\n".join(lines), total


def quote_text_fr(d, items, qid):
    lines = [f"{STORE['name']} — SOUMISSION",
             f"Date : {d.get('date_str','')}   |   Soumission n° {qid or '—'}",
             f"Client : {d.get('customer_name','')} ({'compte garage' if d.get('customer_type')=='garage' else 'détail'})",
             f"Véhicule : {d.get('vehicle_text','')}" + (f"   NIV : {d['vin']}" if d.get("vin") else ""),
             ""]
    total = 0
    for i, it in enumerate(items, 1):
        cat = CAT_FR.get(it["category"], it["category"] or "Pièce")
        # 客户版只显示位置和涂层，不显示内部规格
        attrs = ", ".join(a for a in [it["coated"],
                                      {"L": "gauche", "R": "droite",
                                       "Front": "avant", "Rear": "arrière",
                                       "Left": "gauche", "Right": "droite",
                                       "Front Left": "avant gauche",
                                       "Front Right": "avant droit",
                                       "Rear Left": "arrière gauche",
                                       "Rear Right": "arrière droit"}.get(it["position"],
                                                                          it["position"])] if a)
        price = it["quoted_price"] or 0
        line_total = price * it["qty"]
        total += line_total
        lines.append(f"{i}) {cat} — {it['brand'] or ''}, réf. {it['part_number']}"
                     f"{' (' + attrs + ')' if attrs else ''} x{it['qty']} — {line_total:,.2f} $ CA")
    lines += ["", f"Sous-total : {total:,.2f} $ CA",
              "Prix en dollars canadiens, taxes en sus. Soumission valide 7 jours.",
              f"WhatsApp : {STORE['phone']} | {STORE['addr']}"]
    return "\n".join(lines), total


@app.post("/api/quote_text")
def api_quote_text():
    d = request.get_json(force=True)
    db = get_db()
    items = resolve_items(db, d.get("items", []))
    d = dict(d, date_str=datetime.now().strftime("%Y-%m-%d"))
    en, _ = quote_text_en(d, items, d.get("quote_id"))
    fr, _ = quote_text_fr(d, items, d.get("quote_id"))
    return jsonify({"en": en, "fr": fr})


# ---------- quotes (journal) ----------
@app.post("/api/quotes")
def api_quote_create():
    d = request.get_json(force=True)
    items = d.get("items") or []
    if not items:
        return jsonify({"error": "no items"}), 400
    db = get_db()
    resolved = resolve_items(db, items)
    cid = d.get("customer_id")
    cname = d.get("customer_name")
    if cid and not cname:
        r = db.execute("SELECT name FROM customers WHERE id=?", (cid,)).fetchone()
        if r:
            cname = r["name"]
    cur = db.execute(
        """INSERT INTO quotes(customer_id,customer_name,customer_type,vehicle_id,vehicle_text,
                              vin,status,notes,staff_id)
           VALUES(?,?,?,?,?,?,'pending',?,?)""",
        (cid, cname, d.get("customer_type", "retail"),
         d.get("vehicle_id"), d.get("vehicle_text"), d.get("vin"), d.get("notes"),
         session.get("staff_id")))
    qid = cur.lastrowid
    for it in resolved:
        db.execute(
            """INSERT INTO quote_items(quote_id,part_id,tier,brand,part_number,
                                      specs,cost,quoted_price,qty)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (qid, it["part_id"], it["tier"], it["brand"], it["part_number"],
             it["specs"], it["cost"], it["quoted_price"], it["qty"]))
    db.commit()
    return jsonify({"id": qid}), 201


@app.get("/api/quotes")
def api_quote_list():
    db = get_db()
    conds, args = ["1=1"], []
    if request.args.get("status"):
        conds.append("q.status = ?")
        args.append(request.args["status"])
    if request.args.get("from"):
        conds.append("date(q.created_at) >= date(?)")
        args.append(request.args["from"])
    if request.args.get("to"):
        conds.append("date(q.created_at) <= date(?)")
        args.append(request.args["to"])
    order = "q.id DESC"
    rows = db.execute(
        f"""SELECT q.id, q.created_at, q.customer_id,
                   COALESCE(c.name, q.customer_name) AS customer_name,
                   q.customer_type, q.vehicle_id, q.vehicle_text, q.vin,
                   q.status, q.lost_reason, q.notes, q.staff_id, s.name AS staff_name,
                   COALESCE(SUM(i.quoted_price*i.qty),0) AS total
            FROM quotes q LEFT JOIN quote_items i ON i.quote_id=q.id
            LEFT JOIN customers c ON c.id=q.customer_id
            LEFT JOIN staff s ON s.id=q.staff_id
            WHERE {' AND '.join(conds)}
            GROUP BY q.id ORDER BY {order} LIMIT 500""", args)
    return jsonify([row2dict(r) for r in rows])


@app.get("/api/quotes/<int:qid>")
def api_quote_get(qid):
    db = get_db()
    q = row2dict(db.execute(
        """SELECT q.*, COALESCE(c.name, q.customer_name) AS customer_name, c.ctype AS customer_ctype
           FROM quotes q LEFT JOIN customers c ON c.id=q.customer_id WHERE q.id=?""",
        (qid,)).fetchone())
    if not q:
        return jsonify({"error": "not found"}), 404
    q["items"] = [row2dict(r) for r in
                  db.execute("SELECT * FROM quote_items WHERE quote_id=? ORDER BY id", (qid,))]
    return jsonify(q)


@app.put("/api/quotes/<int:qid>")
def api_quote_replace(qid):
    """Full content replace of a quote (edit flow). Status/staff/created_at preserved."""
    d = request.get_json(force=True)
    items = d.get("items") or []
    if not items:
        return jsonify({"error": "no items"}), 400
    db = get_db()
    if not db.execute("SELECT id FROM quotes WHERE id=?", (qid,)).fetchone():
        return jsonify({"error": "not found"}), 404
    resolved = resolve_items(db, items)
    cid = d.get("customer_id")
    cname = d.get("customer_name")
    if cid and not cname:
        r = db.execute("SELECT name FROM customers WHERE id=?", (cid,)).fetchone()
        if r:
            cname = r["name"]
    db.execute(
        """UPDATE quotes SET customer_id=?,customer_name=?,customer_type=?,
                          vehicle_id=?,vehicle_text=?,vin=?,notes=? WHERE id=?""",
        (cid, cname, d.get("customer_type", "retail"),
         d.get("vehicle_id"), d.get("vehicle_text"), d.get("vin"), d.get("notes"),
         qid))
    db.execute("DELETE FROM quote_items WHERE quote_id=?", (qid,))
    for it in resolved:
        db.execute(
            """INSERT INTO quote_items(quote_id,part_id,tier,brand,part_number,
                                      specs,cost,quoted_price,qty)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (qid, it["part_id"], it["tier"], it["brand"], it["part_number"],
             it["specs"], it["cost"], it["quoted_price"], it["qty"]))
    db.commit()
    return jsonify({"id": qid})


@app.patch("/api/quotes/<int:qid>")
def api_quote_update(qid):
    d = request.get_json(force=True)
    fields = ("status", "lost_reason", "notes", "customer_name")
    sets = [f"{k} = ?" for k in fields if k in d]
    if not sets:
        return jsonify({"error": "nothing to update"}), 400
    if "status" in d and d["status"] not in ("pending", "won", "lost"):
        return jsonify({"error": "bad status"}), 400
    db = get_db()
    db.execute(f"UPDATE quotes SET {', '.join(sets)} WHERE id = ?",
               [d[k] for k in fields if k in d] + [qid])
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/quotes/<int:qid>")
@owner_required_api
def api_quote_delete(qid):
    # quote_items 有 ON DELETE CASCADE，一并删除
    db = get_db()
    q = db.execute("SELECT customer_name, vehicle_text FROM quotes WHERE id=?", (qid,)).fetchone()
    cur = db.execute("DELETE FROM quotes WHERE id=?", (qid,))
    db.commit()
    if not cur.rowcount:
        return jsonify({"error": "not found"}), 404
    if q:
        audit("delete_quote", "quote", qid,
              f"{q['customer_name'] or ''} / {q['vehicle_text'] or ''}".strip(" /"))
    return jsonify({"ok": True})


# ---------- analytics ----------
@app.get("/api/analytics")
def api_analytics():
    db = get_db()
    t = row2dict(db.execute(
        """SELECT COUNT(*) AS quotes,
                  SUM(status='won') AS won, SUM(status='lost') AS lost,
                  SUM(status='pending') AS pending FROM quotes""").fetchone())
    won, lost = t["won"] or 0, t["lost"] or 0
    conv = {"won": won, "lost": lost,
            "rate": (won / (won + lost)) if (won + lost) else 0}

    by_tier = []
    for tier in ("economy", "standard", "premium"):
        r = row2dict(db.execute(
            """SELECT COUNT(DISTINCT q.id) AS total,
                      SUM(CASE WHEN q.status='won' THEN 1 ELSE 0 END) AS won
               FROM quotes q JOIN quote_items i ON i.quote_id=q.id
               WHERE i.tier=? AND q.status IN ('won','lost')""", (tier,)).fetchone())
        tot = r["total"] or 0
        by_tier.append({"tier": tier, "total": tot, "won": r["won"] or 0,
                        "rate": (r["won"] / tot) if tot else 0})

    per_day = [row2dict(r) for r in db.execute(
        """SELECT date(created_at) AS day, COUNT(*) AS n FROM quotes
           WHERE date(created_at) >= date('now','localtime','-13 days')
           GROUP BY day ORDER BY day""")]
    # fill missing days
    have = {d["day"]: d["n"] for d in per_day}
    per_day = [{"day": (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d"),
                "n": have.get((datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d"), 0)}
               for i in range(13, -1, -1)]

    top_cats = [row2dict(r) for r in db.execute(
        """SELECT c.name AS name, COUNT(*) AS n FROM quote_items i
           JOIN parts p ON p.id=i.part_id JOIN categories c ON c.id=p.category_id
           GROUP BY c.name ORDER BY n DESC LIMIT 5""")]
    # 热门件号：用 quote_items 快照（配件删了也不丢）；品类从 parts 关联取
    top_parts = [row2dict(r) for r in db.execute(
        """SELECT i.brand AS brand, i.part_number AS part_number,
                  MAX(c.name) AS category,
                  COUNT(*) AS lines, SUM(i.qty) AS qty,
                  SUM(CASE WHEN q.status='won' THEN i.qty ELSE 0 END) AS won_qty
           FROM quote_items i JOIN quotes q ON q.id=i.quote_id
           LEFT JOIN parts p ON p.id=i.part_id
           LEFT JOIN categories c ON c.id=p.category_id
           WHERE i.part_number IS NOT NULL AND i.part_number != ''
           GROUP BY i.brand, i.part_number
           ORDER BY lines DESC LIMIT 10""")]
    # 热门车型
    top_vehicles = [row2dict(r) for r in db.execute(
        """SELECT q.vehicle_text AS vehicle, COUNT(*) AS quotes,
                  SUM(CASE WHEN q.status='won' THEN 1 ELSE 0 END) AS won,
                  COALESCE(SUM(t.total),0) AS amount
           FROM quotes q
           LEFT JOIN (SELECT quote_id, SUM(quoted_price*qty) AS total
                      FROM quote_items GROUP BY quote_id) t ON t.quote_id=q.id
           WHERE q.vehicle_text IS NOT NULL AND q.vehicle_text != ''
           GROUP BY q.vehicle_text
           ORDER BY quotes DESC LIMIT 10""")]
    lost_reasons = [row2dict(r) for r in db.execute(
        """SELECT COALESCE(NULLIF(lost_reason,''),'(未填)') AS reason, COUNT(*) AS n
           FROM quotes WHERE status='lost' GROUP BY reason ORDER BY n DESC""")]
    per_staff = [row2dict(r) for r in db.execute(
        """SELECT COALESCE(s.name,'(未知)') AS name,
                  COUNT(*) AS quotes,
                  SUM(q.status='won') AS won, SUM(q.status='lost') AS lost,
                  SUM(q.status='pending') AS pending,
                  COALESCE(SUM(CASE WHEN q.status='won' THEN t.total ELSE 0 END),0) AS won_amount
           FROM quotes q LEFT JOIN staff s ON s.id=q.staff_id
           LEFT JOIN (SELECT quote_id, SUM(quoted_price*qty) AS total
                      FROM quote_items GROUP BY quote_id) t ON t.quote_id=q.id
           GROUP BY name ORDER BY quotes DESC""")]
    return jsonify({"totals": t, "conversion": conv, "by_tier": by_tier,
                    "per_day": per_day, "top_categories": top_cats,
                    "top_parts": top_parts, "top_vehicles": top_vehicles,
                    "lost_reasons": lost_reasons, "per_staff": per_staff})


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=8091)
