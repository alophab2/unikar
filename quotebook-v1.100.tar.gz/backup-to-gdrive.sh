#!/bin/bash
# QuoteBook 每日自动备份到 Google Drive，只保留最新 7 份
set -e
DB="/opt/quotebook/data/quotebook.db"
BACKUP_DIR="/opt/quotebook/backups"
REMOTE="gdrive:QuoteBook-backups"
mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M)
FILE="quotebook-${TS}.db"
# SQLite 在线备份，服务不用停
sqlite3 "$DB" ".backup '$BACKUP_DIR/$FILE'"
# 上传到 Google Drive
rclone copy "$BACKUP_DIR/$FILE" "$REMOTE/" --quiet
# 本地只留最新 7 份
ls -t "$BACKUP_DIR"/quotebook-*.db 2>/dev/null | tail -n +8 | xargs -r rm -f
# Drive 上只留最新 7 份（文件名含日期，倒序排）
rclone lsf "$REMOTE" 2>/dev/null | grep '\.db$' | sort -r | tail -n +8 | while read -r f; do
  rclone delete "$REMOTE/$f" --quiet
done
echo "[$(date '+%F %T')] backup $FILE OK"
