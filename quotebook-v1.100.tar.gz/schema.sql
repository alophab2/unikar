-- QuoteBook v1 schema (SQLite)
-- vehicles: one row per vehicle the shop quotes for
CREATE TABLE IF NOT EXISTS vehicles (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    label      TEXT NOT NULL UNIQUE,   -- e.g. "2021 Chevrolet Silverado 1500"
    year       TEXT,
    make       TEXT,
    model      TEXT,
    trim       TEXT,
    drivetrain TEXT,                   -- 'FWD' | 'AWD' | 'RWD' | '4WD' | NULL
    fuel       TEXT,                   -- 'gas' | 'diesel' | 'hybrid' | 'electric' | NULL
    notes      TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- categories: part categories (Chinese UI names)
CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE              -- e.g. "刹车盘"
);

-- parts: reference data. cost = supplier/our cost (from Nexpart "Your Price" at seed time).
-- price_retail / price_garage mirror capp's price levels; NULL = not set yet (fill in 配件管理).
CREATE TABLE IF NOT EXISTS parts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    vehicle_id   INTEGER NOT NULL REFERENCES vehicles(id),
    category_id  INTEGER NOT NULL REFERENCES categories(id),
    brand        TEXT,
    part_number  TEXT NOT NULL,
    specs        TEXT,                      -- e.g. "343mm vented"
    coated       TEXT,                      -- 'coated' | 'uncoated' | NULL
    position     TEXT,                      -- 'L' | 'R' | NULL
    fitment_notes TEXT,
    tier         TEXT,                      -- 'good' | 'better' | 'best' | NULL
    cost         REAL,
    stock_note   TEXT,                      -- supplier stock SNAPSHOT (volatile!)
    stock_updated_at TEXT,                  -- when the snapshot was taken (localtime)
    seller       TEXT,
    price_retail REAL,
    price_garage REAL,
    oem_number   TEXT,                      -- future: OEM bridge for interchange
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_parts_vehicle_cat ON parts(vehicle_id, category_id);

-- staff: counter staff logins (multi-user). First staff created via /login setup = owner.
CREATE TABLE IF NOT EXISTS staff (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE,
    pin_hash   TEXT NOT NULL,
    is_owner   INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- customers: customer directory for the quote flow (step 3: vehicle → parts → customer → quote)
CREATE TABLE IF NOT EXISTS customers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    phone      TEXT,
    ctype      TEXT NOT NULL DEFAULT 'retail',   -- 'retail' | 'garage'
    notes      TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- quotes: the quote journal (workbook role) — one row per customer quote
CREATE TABLE IF NOT EXISTS quotes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    customer_id   INTEGER REFERENCES customers(id),
    customer_name TEXT,
    customer_type TEXT NOT NULL DEFAULT 'retail',  -- 'retail' | 'garage'
    vehicle_id    INTEGER REFERENCES vehicles(id),
    vehicle_text  TEXT,
    vin           TEXT,
    status        TEXT NOT NULL DEFAULT 'pending',  -- 'pending' | 'won' | 'lost'
    lost_reason   TEXT,
    notes         TEXT
);

-- quote_items: line items of a quote (snapshot — survives later part edits)
CREATE TABLE IF NOT EXISTS quote_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_id     INTEGER NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
    part_id      INTEGER REFERENCES parts(id),
    tier         TEXT,
    brand        TEXT,
    part_number  TEXT,
    specs        TEXT,
    cost         REAL,
    quoted_price REAL,
    qty          INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_items_quote ON quote_items(quote_id);

-- audit_log: who did what (deletes, price changes) — owner-only view
CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    staff_id    INTEGER REFERENCES staff(id),
    staff_name  TEXT,
    action      TEXT NOT NULL,   -- 'delete_part' | 'delete_quote' | 'delete_staff' | 'price_change' ...
    target_type TEXT,            -- 'part' | 'quote' | 'staff' | ...
    target_id   INTEGER,
    details     TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(created_at);

-- supplier_prices: per-supplier cost tracking for the same part
-- parts.cost = best (lowest) known cost; parts.seller = supplier with best price
CREATE TABLE IF NOT EXISTS supplier_prices (
    id          INTEGER PRIMARY KEY,
    part_id     INTEGER NOT NULL REFERENCES parts(id) ON DELETE CASCADE,
    supplier    TEXT NOT NULL,
    cost        REAL,
    stock_note  TEXT,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(part_id, supplier)
);
CREATE INDEX IF NOT EXISTS idx_sp_part ON supplier_prices(part_id);

-- csv_import_config: singleton (id=1) — capp CSV 导入的列映射与上次导入摘要
CREATE TABLE IF NOT EXISTS csv_import_config (
    id           INTEGER PRIMARY KEY CHECK (id=1),
    mapping      TEXT,                      -- JSON: {part_number, cost, price_retail, price_garage, stock_qty, description} -> 列名
    last_run     TEXT,
    last_summary TEXT,                      -- JSON summary of last run
    updated_at   TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- csv_import_log: 每次 CSV 导入的记录
CREATE TABLE IF NOT EXISTS csv_import_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ran_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    filename  TEXT,
    rows_read INTEGER,
    matched   INTEGER,                      -- 命中的配件数
    updated   INTEGER,                      -- 更新的配件行数
    unmatched INTEGER,                      -- 未匹配的件号数
    details   TEXT                          -- JSON: {unmatched_sample:[...]}
);
